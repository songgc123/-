# core/ config.py
import os

# ===== 读取环境变量 =====
ALIYUN_API_KEY = os.getenv("DASHSCOPE_API_KEY")
ALIYUN_BASE_URL = os.getenv(
    "ALIYUN_BASE_URL",
    "https://dashscope.aliyuncs.com/api/v1"
).strip()
ALIYUN_MODEL_NAME = os.getenv("ALIYUN_MODEL_NAME", "qwen-turbo")

# ===== 调试输出 =====
print(f"DEBUG: ALIYUN_BASE_URL (repr): {repr(ALIYUN_BASE_URL)}")
print(f"DEBUG: ALIYUN_BASE_URL length: {len(ALIYUN_BASE_URL)}")

# ===== 其他配置 =====
UPLOAD_DIR = "uploads"
OUTPUT_DIR = "outputs"