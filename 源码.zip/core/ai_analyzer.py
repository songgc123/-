# core/ai_analyzer.py
from openai import OpenAI
from core.config import ALIYUN_API_KEY, ALIYUN_BASE_URL, ALIYUN_MODEL_NAME
import json

client = OpenAI(
    api_key=ALIYUN_API_KEY,
    base_url=ALIYUN_BASE_URL.rstrip("/")
)

# --- Prompt 定义 ---
# 文本块分类任务提示词
TextLabelPrompt = """
**Role**: You are a specialized AI assistant for academic paper analysis, proficient in classifying the content of research paper sections.
**Task**: Your primary function is to read the provided text block from a research paper and assign it the single most fitting label from the three predefined categories below.
**Label Definitions**:
method: The text describes the core novel contribution of the paper. This includes the architecture, algorithm, framework, or key theoretical ideas introduced by the authors. This section answers the question, "What is the new technique being proposed in this work?"
experiment setting: The text details the setup for the main experiments where the proposed method is evaluated. This includes descriptions of datasets, evaluation metrics, implementation details, hyperparameter settings, and the baseline models used for comparison.
main experiment result: The text presents the key experimental results that validate the effectiveness of the paper's proposed method. This typically involves direct comparisons against baseline or state-of-the-art methods in tables and figures, showcasing the performance of the new approach.
**Input Format:** Content: {content}
**Output format:** Your output must be a single string, containing strictly one of the three labels (method, experiment setting, or main experiment result). Do not include any explanations or extraneous text.
"""

# 方法总结任务提示词
MethodPrompt = """
As a research paper reading assistant, your task is to analyze the following methodology section. Break down the core method into its essential steps and describe them succinctly. Focus on the "how" of their approach.
**Input:** {method_text}
**Output:** A summary in Chinese that clearly outlines the primary steps of the paper's methodology.
"""


def call_aliyun_api(system_prompt: str, user_prompt: str, model_name: str = ALIYUN_MODEL_NAME) -> str:
    """
    调用阿里云 API。

    Args:
        system_prompt (str): 系统角色提示词。
        user_prompt (str): 用户输入提示词。
        model_name (str): 模型名称。

    Returns:
        str: API 返回的文本内容。
    """
    # --- 添加调试信息 ---
    print(f"DEBUG: Calling API with model: {model_name}")
    print(f"DEBUG: System prompt: {system_prompt[:100]}...")  # 打印前100个字符
    print(f"DEBUG: User prompt: {user_prompt[:100]}...")  # 打印前100个字符
    print(f"DEBUG: Client base_url: '{client.base_url}'")  # <--- 添加这行
    # --- 添加调试信息结束 ---

    try:
        completion = client.chat.completions.create(
            model=model_name,
            messages=[
                {'role': 'system', 'content': system_prompt},
                {'role': 'user', 'content': user_prompt}
            ],
        )
        result = completion.model_dump_json()
        response = json.loads(result)
        final_result = response['choices'][0]['message']['content']
        return final_result
    except Exception as e:
        print(f"API call failed: {e}")
        return f"Error: {e}"


def analyze_text_block(content: str) -> str:
    """
    对单个文本块进行标签分析。

    Args:
        content (str): 要分析的文本块。

    Returns:
        str: 分析得到的标签 (method, experiment setting, main experiment result) 或错误信息。
    """
    prompt = TextLabelPrompt.format(content=content)
    # 注意：这里 system_prompt 为空，因为 TextLabelPrompt 包含了 Role 和 Task 定义
    # 如果 API 要求必须有 system 角色，则需要调整 prompt 结构
    system_input = ""
    user_input = prompt
    return call_aliyun_api(system_input, user_input)


def summarize_method(method_text: str) -> str:
    """
    对方法部分的文本进行总结。

    Args:
        method_text (str): 方法部分的文本。

    Returns:
        str: 总结内容。
    """
    prompt = MethodPrompt.format(method_text=method_text)
    system_input = ""
    user_input = prompt
    return call_aliyun_api(system_input, user_input)


# --- 报告生成逻辑 (示例) ---
def generate_structured_report(analysis_results: list[dict]) -> str:
    """
    根据分析结果生成结构化报告。

    Args:
        analysis_results (list[dict]): 包含文本块、标签、总结等信息的列表。

    Returns:
        str: 生成的 Markdown 格式报告。
    """
    report_parts = {
        "Motivation": [],
        "Method": [],
        "Experiment Setting": [],
        "Experiment Result": [],
        "Other": []
    }

    for result in analysis_results:
        block_content = result.get("content", "")
        label = result.get("label", "Other")
        summary = result.get("summary", "")

        if label == "method":
            report_parts["Method"].append(f"### {result.get('title', 'Method Section')}\n\n{block_content}\n\n**Summary:** {summary}\n\n")
        elif label == "experiment setting":
            report_parts["Experiment Setting"].append(f"### {result.get('title', 'Experiment Setting')}\n\n{block_content}\n\n")
        elif label == "main experiment result":
            report_parts["Experiment Result"].append(f"### {result.get('title', 'Experiment Result')}\n\n{block_content}\n\n")
        else:
            report_parts["Other"].append(f"### {result.get('title', 'Other Section')}\n\n{block_content}\n\n")

    report_md = "# Structured Report\n\n"
    for section, parts in report_parts.items():
        if parts:
            report_md += f"## {section}\n\n" + "".join(parts) + "\n"

    return report_md