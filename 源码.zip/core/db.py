# core/db.py
from sqlalchemy import create_engine, Column, Integer, String, DateTime, LargeBinary, ForeignKey, Boolean, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, relationship
from datetime import datetime
import os
from dotenv import load_dotenv
from werkzeug.security import generate_password_hash, check_password_hash # 导入安全哈希函数

load_dotenv()

# --- 数据库连接配置 ---
DB_HOST = os.getenv("DB_HOST", "127.0.0.1")  # 通常为 127.0.0.1 或 localhost
DB_PORT = int(os.getenv("DB_PORT", 3306))   # 通常为 3306
DB_NAME = os.getenv("DB_NAME", "literature_analysis")  # 确保数据库名正确
DB_USER = os.getenv("DB_USER", "lit_app")  # 确保用户名正确
DB_PASSWORD = os.getenv("DB_PASSWORD", "tzx20050710")  # 确保密码正确

DATABASE_URL = (
    f"mysql+pymysql://{DB_USER}:{DB_PASSWORD}"
    f"@{DB_HOST}:{DB_PORT}/{DB_NAME}?charset=utf8mb4"
)

engine = create_engine(
    DATABASE_URL,
    pool_pre_ping=True,
    pool_recycle=3600
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine
)

Base = declarative_base()

# --- 数据库模型定义 (对应你的 literature_system_schema.sql) ---

class User(Base):
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=False)
    hashed_password = Column(String(255), nullable=False) # 存储哈希后的密码
    created_at = Column(DateTime, default=datetime.utcnow)
    is_active = Column(Boolean, default=True)

    # 关系：一个用户可以有多个报告
    reports = relationship("Report", back_populates="owner")
    tasks = relationship("Task", back_populates="user") # 添加与 Task 的关系

# ===============================
# Report ORM (报告)
# ===============================
class Report(Base):
    __tablename__ = "reports"

    id = Column(Integer, primary_key=True, index=True)
    owner_id = Column(Integer, ForeignKey("users.id"), nullable=False) # 外键关联用户
    # --- 修改：添加 task_id 外键 ---
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=True) # 关联到任务，允许为空
    # --- 修改结束 ---
    title = Column(String(255), nullable=False) # 报告标题，可以是文件名
    content = Column(LargeBinary, nullable=False) # 报告内容 (Markdown bytes)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    # 可以根据需要添加更多字段，如 status (processing, completed, failed)

    # 关系：一个报告属于一个用户
    owner = relationship("User", back_populates="reports")
    # --- 修改：修正与 Task 的关系 ---
    task = relationship("Task", back_populates="reports") # 正向关联 Task，使用 back_populates
    # --- 修改结束 ---

# ===============================
# Task ORM (导读任务)
# ===============================
class Task(Base):
    __tablename__ = "tasks"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)
    title = Column(String(100), nullable=False)
    paper_count = Column(Integer, default=0)
    status = Column(String(20), default="pending")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(
        DateTime,
        default=datetime.utcnow,
        onupdate=datetime.utcnow
    )

    # relationships
    user = relationship("User", back_populates="tasks") # 反向关联 User
    papers = relationship(
        "Paper",
        back_populates="task",
        cascade="all, delete-orphan"
    )
    # --- 修改：修正与 Report 的关系 ---
    reports = relationship("Report", back_populates="task") # 反向关联 Report，使用 back_populates
    # --- 修改结束 ---


# ===============================
# Paper ORM (论文文件)
# ===============================
class Paper(Base):
    __tablename__ = "papers"

    id = Column(Integer, primary_key=True, index=True)
    task_id = Column(Integer, ForeignKey("tasks.id"), nullable=False)
    title = Column(String(300))
    file_name = Column(String(200), nullable=False)
    file_path = Column(String(300), nullable=False)
    md_path = Column(String(300))
    upload_time = Column(DateTime, default=datetime.utcnow)

    # relationships
    task = relationship("Task", back_populates="papers") # 反向关联 Task
    parsed_blocks = relationship("ParsedBlock", back_populates="paper", cascade="all, delete-orphan") # 正向关联 ParsedBlock


# ===============================
# ParsedBlock ORM (解析后的文本块)
# ===============================
class ParsedBlock(Base):
    __tablename__ = "parsed_blocks"

    id = Column(Integer, primary_key=True, index=True)
    paper_id = Column(Integer, ForeignKey("papers.id"), nullable=False) # 外键关联 Paper
    block_type = Column(String(50), default="other") # 块类型，如 method, experiment, result 等
    heading = Column(String(300)) # 块标题 (可选)
    section_index = Column(Integer) # 在论文中的顺序索引 (可选)
    content = Column(Text, nullable=False) # 块的实际内容
    created_at = Column(DateTime, default=datetime.utcnow)

    # relationship
    paper = relationship("Paper", back_populates="parsed_blocks") # 反向关联 Paper


# --- CRUD 操作函数 (作为数据库的“唯一出口”) ---

def get_db():
    """Dependency for getting a database session."""
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# --- User 相关操作 ---

def get_user_by_username(db_session, username: str):
    """根据用户名查找用户"""
    return db_session.query(User).filter(User.username == username).first()

def get_user_by_email(db_session, email: str):
    """根据邮箱查找用户"""
    return db_session.query(User).filter(User.email == email).first()

def create_user(db_session, username: str, email: str, password: str):
    """创建新用户"""
    # 使用 werkzeug 提供的安全哈希函数
    hashed_pw = generate_password_hash(password, method='pbkdf2:sha256', salt_length=8)
    db_user = User(username=username, email=email, hashed_password=hashed_pw)
    db_session.add(db_user)
    db_session.commit()
    db_session.refresh(db_user)
    return db_user

def authenticate_user(db_session, username: str, password: str):
    """验证用户凭据"""
    user = get_user_by_username(db_session, username)
    if not user or not check_password_hash(user.hashed_password, password):
        return None
    return user

# --- Report 相关操作 ---

def create_report(db_session, owner_id: int, title: str, content: str, task_id: int = None): # <--- 添加 task_id 参数
    """创建新报告"""
    # 将 Markdown 字符串编码为 bytes 存储
    content_bytes = content.encode('utf-8')
    db_report = Report(owner_id=owner_id, task_id=task_id, title=title, content=content_bytes) # <--- 传递 task_id
    db_session.add(db_report)
    db_session.commit()
    db_session.refresh(db_report)
    return db_report

def get_reports_by_owner(db_session, owner_id: int, skip: int = 0, limit: int = 100):
    """根据用户 ID 获取报告列表"""
    return db_session.query(Report).filter(Report.owner_id == owner_id).offset(skip).limit(limit).all()

def get_report_by_id(db_session, report_id: int):
    """根据 ID 获取单个报告"""
    return db_session.query(Report).filter(Report.id == report_id).first()

def update_report_content(db_session, report_id: int, new_content: str):
    """更新报告内容"""
    report = db_session.query(Report).filter(Report.id == report_id).first()
    if report:
        report.content = new_content.encode('utf-8')
        report.updated_at = datetime.utcnow()
        db_session.commit()
        db_session.refresh(report)
        return report
    return None

def delete_report(db_session, report_id: int):
    """删除报告"""
    report = db_session.query(Report).filter(Report.id == report_id).first()
    if report:
        db_session.delete(report)
        db_session.commit()
        return True
    return False


# ===============================
# Task / Paper CRUD
# ===============================
def create_task(db, user_id: int, title: str):
    task = Task(user_id=user_id, title=title)
    db.add(task)
    db.commit()
    db.refresh(task)
    return task


def get_tasks_by_user(db_session, user_id: int):
    """获取指定用户的任务列表"""
    tasks = db_session.query(Task).filter(Task.user_id == user_id).all()

    # --- 修改：将 SQLAlchemy Task 对象转换为字典列表 ---
    task_list = []
    for t in tasks:
        task_dict = {
            "id": t.id,
            "title": t.title,
            "user_id": t.user_id,
            "paper_count": t.paper_count,
            "status": t.status, # <--- 添加 status 字段
            "created_at": t.created_at.isoformat(),
            "updated_at": t.updated_at.isoformat(),
            # 如果有其他需要返回的字段，可以在这里添加
        }
        task_list.append(task_dict)
    return task_list


def get_task_by_id(db, task_id: int):
    return db.query(Task).filter(Task.id == task_id).first()


def add_paper_to_task(
    db,
    task_id: int,
    file_name: str,
    file_path: str,
    title: str = None,
    md_path: str = None
):
    paper = Paper(
        task_id=task_id,
        file_name=file_name,
        file_path=file_path,
        title=title,
        md_path=md_path
    )
    db.add(paper)

    # 同步更新论文数量（工程级必须）
    db.query(Task).filter(Task.id == task_id).update({
        Task.paper_count: Task.paper_count + 1
    })

    db.commit()
    db.refresh(paper)
    return paper


# ===============================
# ParsedBlock CRUD
# ===============================

def create_parsed_block(db_session, paper_id: int, block_type: str, content: str, heading: str = None, section_index: int = None):
    """
    创建一个新的解析块记录
    """
    db_parsed_block = ParsedBlock(
        paper_id=paper_id,
        block_type=block_type,
        content=content,
        heading=heading,
        section_index=section_index
    )
    db_session.add(db_parsed_block)
    db_session.commit()
    db_session.refresh(db_parsed_block)
    return db_parsed_block

def get_parsed_blocks_by_paper(db_session, paper_id: int):
    """
    根据论文 ID 获取所有解析块
    """
    return db_session.query(ParsedBlock).filter(ParsedBlock.paper_id == paper_id).all()

def get_parsed_block_by_id(db_session, block_id: int):
    """
    根据 ID 获取单个解析块
    """
    return db_session.query(ParsedBlock).filter(ParsedBlock.id == block_id).first()

def update_parsed_block_content(db_session, block_id: int, new_content: str):
    """
    更新解析块内容
    """
    block = db_session.query(ParsedBlock).filter(ParsedBlock.id == block_id).first()
    if block:
        block.content = new_content
        # 注意：ParsedBlock 模型中没有 updated_at 字段，所以这里不更新
        # block.updated_at = datetime.utcnow() # 如果有 updated_at 字段
        db_session.commit()
        db_session.refresh(block)
        return block
    return None

def delete_parsed_block(db_session, block_id: int):
    """
    删除单个解析块
    """
    block = db_session.query(ParsedBlock).filter(ParsedBlock.id == block_id).first()
    if block:
        db_session.delete(block)
        db_session.commit()
        return True
    return False


# --- 初始化数据库表 ---
# 在应用启动时调用此函数 (例如在 main/app.py 中)
def init_db():
    Base.metadata.create_all(bind=engine)