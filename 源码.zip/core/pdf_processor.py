# core/pdf_processor.py

import os
import tempfile
import requests
import time
import zipfile
import io
from pathlib import Path

# --- 配置 MinerU API ---
MINERU_API_TOKEN = os.getenv("MINERU_API_TOKEN", "你的实际API_TOKEN") # 从环境变量获取
MINERU_CREATE_TASK_URL = "https://mineru.net/api/v4/extract/task"
MINERU_POLL_INTERVAL = 10 # 轮询间隔（秒）
MINERU_MAX_POLL_TIME = 1800 # 最大轮询时间（秒），例如 30 分钟

def process_pdf(pdf_url: str): # 修改函数签名，接收 URL
    """
    Process a PDF file by calling the MinerU API service.
    Expects a publicly accessible URL to the PDF file.
    Returns the markdown content and an empty image directory path.
    """
    print(f"INFO: Calling MinerU API for PDF URL: {pdf_url}")

    headers = {
        "Authorization": f"Bearer {MINERU_API_TOKEN}",
        "Content-Type": "application/json"
    }

    # --- 1. 发送 POST 请求到 MinerU API 创建任务 ---
    payload = {
        "url": pdf_url,
        "model_version": "vlm", # 或 "pipeline"，根据需要
        # 可以根据需要添加其他参数，如 is_ocr, enable_formula, language 等
        # "is_ocr": False,
        # "enable_formula": True,
        # "language": "ch",
    }

    try:
        print(f"INFO: Sending request to {MINERU_CREATE_TASK_URL}")
        response = requests.post(MINERU_CREATE_TASK_URL, headers=headers, json=payload, timeout=30)

        if not response.ok:
            error_data = response.json() if response.headers.get('Content-Type', '').startswith('application/json') else response.text
            print(f"ERROR: MinerU API request failed: {response.status_code} - {error_data}")
            raise Exception(f"MinerU API request failed: {response.status_code} - {error_data}")

        api_response = response.json()
        code = api_response.get("code")
        msg = api_response.get("msg")
        task_id = api_response.get("data", {}).get("task_id")

        if code != 0 or not task_id:
            print(f"ERROR: MinerU API returned error or no task_id. Code: {code}, Msg: {msg}, Response: {api_response}")
            raise Exception(f"MinerU API error: {msg or 'No task_id returned'} - {api_response}")

        print(f"INFO: MinerU API task created successfully. Task ID: {task_id}")

        # --- 2. 轮询任务状态直到完成 ---
        poll_url = f"https://mineru.net/api/v4/extract/task/{task_id}"
        start_time = time.time()
        while time.time() - start_time < MINERU_MAX_POLL_TIME:
            time.sleep(MINERU_POLL_INTERVAL)
            print(f"INFO: Polling MinerU API for task status (ID: {task_id})...")

            poll_response = requests.get(poll_url, headers=headers, timeout=30)
            if not poll_response.ok:
                error_data = poll_response.json() if poll_response.headers.get('Content-Type', '').startswith('application/json') else poll_response.text
                print(f"ERROR: MinerU API poll failed: {poll_response.status_code} - {error_data}")
                raise Exception(f"MinerU API poll failed: {poll_response.status_code} - {error_data}")

            poll_data = poll_response.json()
            poll_code = poll_data.get("code")
            poll_msg = poll_data.get("msg")
            state = poll_data.get("data", {}).get("state")
            err_msg = poll_data.get("data", {}).get("err_msg")

            if poll_code != 0:
                 print(f"ERROR: MinerU API poll returned error. Code: {poll_code}, Msg: {poll_msg}, Response: {poll_data}")
                 raise Exception(f"MinerU API poll error: {poll_msg or 'Unknown error'} - {poll_data}")

            print(f"INFO: Task {task_id} state: {state}")

            if state == "done":
                # --- 3. 任务完成，获取结果 ---
                full_zip_url = poll_data.get("data", {}).get("full_zip_url")
                if not full_zip_url:
                     print(f"ERROR: MinerU API returned task done but no full_zip_url. Response: {poll_data}")
                     raise Exception(f"MinerU API returned task done but no result URL. Response: {poll_data}")

                print(f"INFO: Task {task_id} completed. Downloading result from {full_zip_url}")
                zip_response = requests.get(full_zip_url, timeout=60)
                if not zip_response.ok:
                    print(f"ERROR: Failed to download result zip from {full_zip_url}")
                    raise Exception(f"Failed to download result zip: {zip_response.status_code}")

                # --- 4. 解压并查找 Markdown 文件 ---
                zip_content = io.BytesIO(zip_response.content)
                with zipfile.ZipFile(zip_content, 'r') as zip_ref:
                    file_list = zip_ref.namelist()
                    print(f"INFO: Downloaded zip contains: {file_list}")

                    # 查找 .md 文件 (通常只有一个，或者根据命名规则查找)
                    md_file_name = None
                    for file_name in file_list:
                        if file_name.lower().endswith('.md'):
                            md_file_name = file_name
                            break

                    if not md_file_name:
                        print(f"ERROR: No .md file found in the downloaded zip: {file_list}")
                        raise Exception(f"No .md file found in result zip: {file_list}")

                    print(f"INFO: Extracting markdown file: {md_file_name}")
                    markdown_content = zip_ref.read(md_file_name).decode('utf-8')

                print("INFO: MinerU API call successful, markdown content retrieved.")
                # 假设图片目录在 zip 内，或者 API 服务已处理图片链接
                # 这里简化处理，返回空字符串，表示图片链接在 markdown 内或已处理
                image_dir = "" # 或者解析 zip 获取图片并返回路径
                return markdown_content, image_dir

            elif state == "failed":
                print(f"ERROR: MinerU API task {task_id} failed: {err_msg}")
                raise Exception(f"MinerU API task failed: {err_msg}")

            elif state in ["pending", "running", "converting"]:
                # 继续轮询
                continue

            else:
                # 未知状态
                print(f"ERROR: MinerU API task {task_id} returned unknown state: {state}")
                raise Exception(f"MinerU API task returned unknown state: {state}")

        # 如果循环结束仍未完成
        print(f"ERROR: MinerU API task {task_id} polling timed out after {MINERU_MAX_POLL_TIME} seconds.")
        raise Exception(f"MinerU API task polling timed out after {MINERU_MAX_POLL_TIME} seconds.")

    except requests.exceptions.RequestException as e:
        # 捕获网络请求相关的错误
        print(f"ERROR: Network error during MinerU API call: {str(e)}")
        raise Exception(f"网络错误: {str(e)}")
    except Exception as e:
        # 捕获其他可能的错误
        print(f"ERROR in process_pdf (API client): {str(e)}")
        raise # 重新抛出异常，让调用者处理

# 保留 split_markdown_content 函数
def split_markdown_content(md_content: str) -> list[str]:
    """
    Split markdown content by top-level headers (e.g., # Header).
    """
    if not md_content.strip():
        return []
    # 使用 \n# 来分割，确保保留第一个块（可能没有以 # 开头）
    blocks = md_content.split("\n# ")
    # 重新添加 # 到除了第一个块之外的其他块
    blocks = [blocks[0]] + [f"# {block}" for block in blocks[1:]]
    # 过滤掉空块
    return [block.strip() for block in blocks if block.strip()]


if __name__ == "__main__":
    # 测试 API 调用函数 (需要一个可访问的 PDF URL)
    test_pdf_url = "https://static.openxlab.org.cn/opendatalab/pdf/demo.pdf" # 示例 URL
    try:
        md, img_dir = process_pdf(test_pdf_url)
        print("Received Markdown Content (first 200 chars):")
        print(md[:200])
        print(f"Received Image Directory: {img_dir}")
    except Exception as e:
        print(f"Test failed: {e}")
