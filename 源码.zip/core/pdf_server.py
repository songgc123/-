# server/pdf_server.py

import sys
import os

# 获取 core 目录的父目录 (即 Project 根目录)
project_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# 将 Project 目录添加到 Python 路径的最前面
if project_root not in sys.path:
    sys.path.insert(0, project_root)

from fastapi import FastAPI, UploadFile, File, HTTPException, BackgroundTasks # 修正导入
from fastapi.middleware.cors import CORSMiddleware
import asyncio
import uuid
import json
from pathlib import Path
import tempfile
from core.pdf_processor import process_pdf # 从 core 包导入 process_pdf
from core.config import OUTPUT_DIR # 从 core 包导入 config

app = FastAPI()

# 全局任务状态字典
task_status = {}

# CORS 配置
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"], # 生产环境中应指定具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.post("/process")
async def process_pdf_endpoint(file: UploadFile = File(...), background_tasks: BackgroundTasks = BackgroundTasks()):
    """启动后台任务处理 PDF，并返回任务 ID"""
    if file.size > 30 * 1024 * 1024:
        raise HTTPException(413, "文件超过30MB限制！学术论文建议拆分上传")

    # 生成唯一的任务 ID
    task_id = str(uuid.uuid4())

    # 使用 tempfile 创建临时文件
    temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=os.path.splitext(file.filename)[1])
    temp_path = temp_file.name
    temp_file.close()

    try:
        with open(temp_path, "wb") as f:
            f.write(await file.read())
    except Exception as e:
        if os.path.exists(temp_path):
            os.remove(temp_path)
        raise HTTPException(500, f"文件保存失败: {e}")

    # 更新任务状态为 pending
    task_status[task_id] = {"status": "pending", "message": "文件已接收，等待处理..."}
    # 添加后台任务
    output_dir = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'outputs')
    os.makedirs(output_dir, exist_ok=True)
    background_tasks.add_task(run_pdf_processing_task, task_id, temp_path, output_dir)

    # 立即返回任务 ID，让前端可以轮询或 WebSocket 查询进度
    return {"task_id": task_id, "message": "文件已接收，正在后台处理，请稍后查询结果。"}

# 新增：查询任务状态的 API
@app.get("/task/{task_id}")
async def get_task_status(task_id: str):
    """获取指定任务的状态和结果"""
    if task_id not in task_status:
        raise HTTPException(404, "任务ID不存在")

    status_info = task_status[task_id]

    # 如果任务已完成，返回 markdown 内容
    if status_info["status"] == "completed":
        # 这里假设你有一个函数来读取最终的 Markdown 文件
        # 你需要根据你的实际逻辑来实现
        md_content = await read_markdown_content(status_info.get("output_path"))
        return {
            "status": "completed",
            "markdown": md_content
        }
    elif status_info["status"] == "failed":
        return {
            "status": "failed",
            "error": status_info.get("error", "未知错误")
        }
    else:
        # processing 或 pending
        return {
            "status": status_info["status"],
            "message": status_info.get("message", "")
        }

# 新增：辅助函数，用于读取 Markdown 文件内容
async def read_markdown_content(md_file_path: str) -> str:
    """异步读取 Markdown 文件内容"""
    try:
        with open(md_file_path, "r", encoding="utf-8") as f:
            content = f.read()
        return content
    except Exception as e:
        raise HTTPException(500, f"读取Markdown文件失败: {e}")

# 修改 run_pdf_processing_task 函数
def run_pdf_processing_task(task_id: str, file_path: str, output_dir: str):
    """在后台线程中执行耗时的 PDF 处理"""
    try:
        task_status[task_id] = {"status": "processing", "message": "开始处理..."}
        # 确保 output_dir 是绝对路径且存在
        os.makedirs(output_dir, exist_ok=True)
        md_content, local_image_dir = process_pdf(file_path, output_dir=output_dir, backend="pipeline")
        # 将最终的 Markdown 文件路径存入 task_status，以便 /task/{task_id} 接口读取
        # 假设 process_pdf 返回的 md_content 是字符串，我们将其写入文件
        # 你可以根据你的需求调整
        name_without_suff = os.path.splitext(os.path.basename(file_path))[0]
        md_file_path = os.path.join(output_dir, name_without_suff, f"{name_without_suff}.md")
        with open(md_file_path, "w", encoding="utf-8") as f:
            f.write(md_content)

        task_status[task_id] = {
            "status": "completed",
            "message": "处理完成",
            "output_path": md_file_path # 存储文件路径，供 /task/{task_id} 接口读取
        }
    except Exception as e:
        task_status[task_id] = {
            "status": "failed",
            "error": str(e),
            "message": "处理失败"
        }
    finally:
        # 处理完成后，删除临时文件
        if os.path.exists(file_path):
            os.remove(file_path)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="127.0.0.1", port=8001)