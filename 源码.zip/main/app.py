# main/app.py
import sys
import os
import tempfile
import uuid # 用于生成唯一文件名和 batch_id
import time # 用于轮询和时间戳
import requests # 用于 API 调用
import json # 用于处理 JSON
import zipfile # 用于解压 ZIP 文件
import io # 用于处理内存中的字节流
import shutil # 用于删除文件夹
from datetime import datetime, timedelta # 用于计算时间差
from pathlib import Path
import glob # 用于查找文件
from threading import Lock
from collections import defaultdict

# 获取 core 目录的父目录 (即 Project 根目录)
main_dir = os.path.dirname(os.path.abspath(__file__)) # 获取 main/app.py 的目录 (即 main)
PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))) # 获取 Project 目录
core_dir = os.path.join(PROJECT_ROOT, 'core') # 构造 core 目录的路径

# 将 Project 目录和 core 目录都添加到 Python 路径的最前面
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
if core_dir not in sys.path:
    sys.path.insert(0, core_dir)

# 现在应该可以成功导入 core 下的模块了
from flask import Flask, request, jsonify, send_from_directory, abort
from flask_cors import CORS

# ===== Database (User / Report / Task / Paper) =====
from core.db import (
    SessionLocal,
    get_user_by_username,
    get_user_by_email,
    create_user,
    authenticate_user,
    User,
    create_report,
    get_reports_by_owner,
    get_report_by_id,
    Report,
    init_db,
    engine,
    get_db,
    # ===== Task / Paper =====
    Task,
    Paper,
    ParsedBlock,  # <--- 新增导入 ParsedBlock 模型
    create_task,
    get_tasks_by_user,
    get_task_by_id,  # <--- 注意：这个函数没有 with_papers 参数
    add_paper_to_task,
    create_parsed_block,
    get_parsed_blocks_by_paper
)

# 导入你的AI分析模块
from core.ai_analyzer import call_aliyun_api, analyze_text_block, summarize_method, generate_structured_report # <--- 导入 generate_structured_report
# 导入数据库
from sqlalchemy import text
# 导入其他模块
from core.pdf_processor import split_markdown_content # 注意：process_pdf 将被修改，不再本地执行 MinerU
from core.config import UPLOAD_DIR
from werkzeug.utils import secure_filename

app = Flask(__name__)

# --- 配置 MinerU API ---
MINERU_API_TOKEN = os.getenv("MINERU_API_TOKEN", "你的实际API_TOKEN") # 从环境变量获取
MINERU_BATCH_CREATE_TASK_URL = "https://mineru.net/api/v4/extract/task/batch"
MINERU_BATCH_POLL_URL = "https://mineru.net/api/v4/extract-results/batch/"
MINERU_POLL_INTERVAL = 10  # 轮询间隔（秒）
MINERU_MAX_POLL_TIME = 1800  # 最大轮询时间（秒），例如 30 分钟

# --- 配置临时上传目录 ---
# 假设 uploads 目录在 Project 根目录下
UPLOAD_FOLDER = os.path.join(PROJECT_ROOT, 'uploads') # 指向 Project\uploads
os.makedirs(UPLOAD_FOLDER, exist_ok=True) # 确保目录存在
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# --- 配置输出目录 ---
OUTPUTS_FOLDER = os.path.join(PROJECT_ROOT, 'outputs') # 指向 Project\outputs
os.makedirs(OUTPUTS_FOLDER, exist_ok=True) # 确保目录存在
app.config['OUTPUTS_FOLDER'] = OUTPUTS_FOLDER

_temp_analyze_results_cache = {}
_temp_cache_lock = Lock() # 简单线程锁保护缓存字典

def store_analyze_results_mapping(user_id: int, batch_id: str, mapping: dict, ttl_seconds: int = 3600):
    """
    存储 analyze_pdf 生成的 file_name -> md_path 映射。
    """
    global _temp_analyze_results_cache
    cache_key = f"user_{user_id}_{batch_id}"
    expires_at = time.time() + ttl_seconds

    with _temp_cache_lock:
        _temp_analyze_results_cache[cache_key] = {
            'mapping': mapping,
            'expires_at': expires_at
        }
    print(f"DEBUG [store_analyze_results_mapping]: Stored mapping for key {cache_key}, expires at {time.ctime(expires_at)}")

def get_and_clear_analyze_results_mapping(cache_key: str):
    """
    获取并清除指定 cache_key 的映射。
    如果已过期，则返回 None。
    """
    global _temp_analyze_results_cache
    with _temp_cache_lock:
        entry = _temp_analyze_results_cache.get(cache_key)
        if entry:
            if time.time() > entry['expires_at']:
                print(f"DEBUG [get_and_clear_analyze_results_mapping]: Cache key {cache_key} expired. Removing.")
                del _temp_analyze_results_cache[cache_key]
                return None
            else:
                mapping = entry['mapping']
                # 获取后立即删除，确保一次性使用
                del _temp_analyze_results_cache[cache_key]
                print(f"DEBUG [get_and_clear_analyze_results_mapping]: Retrieved and cleared mapping for key {cache_key}")
                return mapping
        else:
            print(f"DEBUG [get_and_clear_analyze_results_mapping]: No mapping found for key {cache_key}")
            return None


# --- 新增: 定义临时上传文件的访问路由 ---
# 这个路由至关重要！它允许外部服务访问服务器上的文件
@app.route('/temp_uploads/<filename>')
def uploaded_file(filename):
    """
    提供对临时上传文件的访问。
    这个路由将允许远程 MinerU API 通过 URL 下载 PDF。
    """
    print(f"INFO: Serving file request for {filename}")
    return send_from_directory(app.config['UPLOAD_FOLDER'], filename)


# ✅ 明确允许的前端来源（你现在的前端 origin 是 http://localhost 或其他端口）
# 请根据你的前端实际运行的地址修改这里
ALLOWED_ORIGINS = [
    "http://localhost",
    "http://127.0.0.1",
    # 如果你的前端运行在特定端口，例如 http://localhost:8080
    "http://localhost:8080",
    "http://127.0.0.1:8080",
    # 添加你的前端实际运行的 URL
    # "http://localhost:3000", # React 默认
    # "http://localhost:5173", # Vite 默认
]

# ✅ 对 /api/* 统一开启 CORS（更精确控制）
CORS(
    app,
    resources={r"/api/*": {"origins": ALLOWED_ORIGINS}},
    supports_credentials=True, # 如果需要传递 cookies 或认证信息
    methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["Content-Type", "Authorization", "X-Requested-With"],
)

# ✅ 兜底：任何 /api/* 的 OPTIONS 预检都保证 200
@app.before_request
def _handle_preflight():
    if request.method == "OPTIONS" and request.path.startswith("/api/"):
        from flask import make_response
        resp = make_response("", 200)
        origin = request.headers.get("Origin", "")
        if origin in ALLOWED_ORIGINS:
            resp.headers["Access-Control-Allow-Origin"] = origin
        # 确保 Origin 变化时缓存策略正确
        resp.headers["Vary"] = "Origin"
        resp.headers["Access-Control-Allow-Credentials"] = "true"
        resp.headers["Access-Control-Allow-Methods"] = "GET,POST,PUT,DELETE,OPTIONS"
        # 允许前端请求中携带的自定义头部
        req_headers = request.headers.get("Access-Control-Request-Headers", "Content-Type,Authorization,X-Requested-With")
        resp.headers["Access-Control-Allow-Headers"] = req_headers
        return resp


# 启动时初始化数据库表 (如果表不存在)
with app.app_context(): # 在应用上下文中执行
    init_db()


@app.get("/health")
def health():
    with engine.connect() as conn:
        conn.execute(text("SELECT 1"))
    return {"ok": True, "db": "connected"}


# --- 新增用户相关接口 ---

@app.route('/api/user/register', methods=['POST'])
def register_user():
    """
    用户注册接口（最终版）
    """
    data = request.get_json(force=True)
    username = data.get('username', '').strip()
    email = data.get('email', '').strip()
    password = data.get('password', '')

    if not username or not email or not password:
        return jsonify({"error": "用户名、邮箱和密码不能为空"}), 400

    db = SessionLocal()
    try:
        # 用户名唯一性校验
        if get_user_by_username(db, username):
            return jsonify({"error": "用户名已存在"}), 400
        # 邮箱唯一性校验
        if get_user_by_email(db, email):
            return jsonify({"error": "邮箱已被注册"}), 400

        # 创建用户
        user = create_user(db, username, email, password)
        return jsonify({
            "message": "注册成功",
            "user": {
                "id": user.id,
                "username": user.username,
                "email": user.email
            }
        }), 201
    except Exception as e:
        db.rollback()
        app.logger.error(f"注册失败: {str(e)}")
        return jsonify({"error": "服务器内部错误"}), 500
    finally:
        db.close()


@app.route('/api/user/login', methods=['POST'])
def login_user():
    """
    用户登录接口（最终版）
    """
    data = request.get_json(force=True)
    username = data.get('username', '').strip()
    password = data.get('password', '')

    if not username or not password:
        return jsonify({"error": "用户名和密码不能为空"}), 400

    db = SessionLocal()
    try:
        user = authenticate_user(db, username, password)
        if not user:
            return jsonify({"error": "用户名或密码错误"}), 401
        if not user.is_active:
            return jsonify({"error": "账号已被禁用"}), 403

        return jsonify({
            "message": "登录成功",
            "user": {
                "id": user.id,
                "username": user.username,
                "email": user.email
            }
        }), 200
    except Exception as e:
        app.logger.error(f"登录失败: {str(e)}")
        return jsonify({"error": "服务器内部错误"}), 500
    finally:
        db.close()


ANONYMOUS_USER_ID = 999

def clean_old_outputs():
    """
    扫描 outputs 目录，删除超过 1 小时且未被保存的 batch 文件夹。
    """
    print("INFO: Starting cleanup of old outputs...")
    current_time = datetime.now()
    one_hour_ago = current_time - timedelta(hours=1)

    for user_dir_name in os.listdir(app.config['OUTPUTS_FOLDER']):
        user_dir_path = os.path.join(app.config['OUTPUTS_FOLDER'], user_dir_name)
        if not os.path.isdir(user_dir_path):
            continue

        for batch_dir_name in os.listdir(user_dir_path):
            batch_dir_path = os.path.join(user_dir_path, batch_dir_name)
            if not os.path.isdir(batch_dir_path):
                continue

            # 检查文件夹的修改时间（或创建时间，取决于你的系统和需求）
            # 这里使用修改时间作为判断依据
            batch_mtime = datetime.fromtimestamp(os.path.getmtime(batch_dir_path))
            if batch_mtime < one_hour_ago:
                # 检查这个 batch 是否已被保存（例如，检查数据库中是否有对应 report_id 的记录）
                # 由于 report_id 是在 save_report 时生成的，而我们是在 save_report 之前调用此函数，
                # 我们需要一种方式来标记 batch 是否已保存。
                # 一种简单的方式是检查 batch 目录下是否有特定的标记文件（如 .saved 或 .keep）
                # 或者，我们可以假设所有在 outputs 目录下的 batch 都是临时的，除非被明确保存。
                # 为了简单起见，我们假设所有超过 1 小时的 batch 都是未保存的。
                # 如果需要更精确的控制，可以考虑在创建 batch 目录时创建一个 .temp 文件，
                # 在 save_report 时将其重命名为 .saved 或删除 .temp 文件。
                # 这里我们直接删除超过 1 小时的 batch 目录。
                try:
                    shutil.rmtree(batch_dir_path)
                    print(f"INFO: Deleted old batch directory: {batch_dir_path}")
                except OSError as e:
                    print(f"ERROR: Failed to delete old batch directory {batch_dir_path}: {e}")
    print("INFO: Cleanup of old outputs completed.")


@app.route('/api/paper/analyze', methods=['POST'])
def analyze_pdf():
    """
    上传多个 PDF 文件并进行分析，将结果保存到本地 outputs 目录。
    解析完成后，调用 AI 生成导读报告，并返回报告内容。
    如果未提供 user_id，则使用默认的匿名用户 ID。
    """
    print("=== DEBUG: /api/paper/analyze route was hit! ===")
    import sys
    sys.stdout.flush() # 强制刷新输出缓冲区，确保 print 立即显示

    # --- 触发清理旧输出 ---
    clean_old_outputs()

    uploaded_files = request.files.getlist('files') # 假设前端字段名为 'files'
    if not uploaded_files or (len(uploaded_files) == 1 and uploaded_files[0].filename == ''):
        return jsonify({"error": "未找到文件"}), 400

    # 验证所有文件是否为 PDF
    for file in uploaded_files:
        if not file.filename.lower().endswith('.pdf'):
            return jsonify({"error": f"文件 '{file.filename}' 不是 PDF 格式"}), 400

    # 获取用户ID (假设前端通过 form-data 一起传递)
    user_id_str = request.form.get('user_id', '') # 获取 user_id，可能为空
    user_id = None # 初始化 user_id

    if user_id_str and user_id_str.isdigit():
        user_id = int(user_id_str)
        print(f"userid is {user_id}")
    else:
        # 如果没有提供 user_id 或 user_id 无效，则使用默认的匿名用户 ID
        user_id = ANONYMOUS_USER_ID
        print(f"使用默认匿名用户 ID: {user_id} 存储报告") # 可选：记录日志

    task_id_str = request.form.get('task_id')  # 从前端的 FormData 获取 task_id
    task_id = None
    if task_id_str:
        try:
            task_id = int(task_id_str)
            print(f"DEBUG [analyze_pdf]: Received task_id {task_id} from frontend.")
        except ValueError:
            print(f"DEBUG [analyze_pdf]: Invalid task_id format received: '{task_id_str}'. Ignoring.")
            task_id = None  # 如果格式错误，忽略
    else:
        print(f"DEBUG [analyze_pdf]: No task_id received from frontend.")

    # --- 1. 保存所有文件到本地 uploads 目录并生成 URL 列表 ---
    file_urls = []
    file_info_map = {} # 用于关联上传的文件名和本地路径、生成的 URL
    temp_file_paths = [] # 记录临时文件路径，用于最后清理

    for file in uploaded_files:
        try:
            # --- 1.1. 生成唯一的文件名 ---
            original_filename = os.path.basename(file.filename) # 获取原始文件名
            unique_filename = f"{uuid.uuid4()}_{original_filename}" # 生成唯一文件名
            print(f"INFO: Generated unique filename for upload: {unique_filename}")

            # --- 1.2. 保存文件到本地 uploads 目录 ---
            temp_file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
            file.save(temp_file_path)
            temp_file_paths.append(temp_file_path) # 记录路径用于后续清理
            print(f"INFO: Saved uploaded file to {temp_file_path}")

            # --- 1.3. 构建可访问的 URL (使用你的公网 IP) ---
            # **重要**: 将 http://8.136.43.23:5000 替换为你服务器的实际公网 IP 和端口
            pdf_url = f"http://8.136.43.23:5000/temp_uploads/{unique_filename}" # <--- 替换为你的公网 IP
            file_urls.append(pdf_url)
            file_info_map[original_filename] = {
                "url": pdf_url,
                "local_path": temp_file_path
            }
            print(f"INFO: Generated public PDF URL for {original_filename}: {pdf_url}")

        except Exception as e:
            print(f"ERROR in analyze_pdf (upload loop): {str(e)}")
            app.logger.error(f"保存文件 {original_filename} 时发生未知错误: {str(e)}", exc_info=True)
            # 如果保存失败，清理已保存的文件并返回错误
            for path in temp_file_paths:
                if os.path.exists(path):
                    os.remove(path)
                    print(f"Cleaned up temporary file due to error: {path}")
            return jsonify({"error": f"保存文件 {original_filename} 时发生未知错误: {str(e)}"}), 500

    # --- 2. 调用 MinerU 批量 API ---
    print(f"INFO: Calling MinerU Batch API with {len(file_urls)} files")
    headers = {
        "Authorization": f"Bearer {MINERU_API_TOKEN}",
        "Content-Type": "application/json"
    }

    # 构建请求体，使用 URL 方式
    mineru_files_payload = []
    for filename, info in file_info_map.items():
        # 每个文件项，可以包含 data_id, page_ranges 等参数
        mineru_files_payload.append({
            "url": info["url"],
            "data_id": str(uuid.uuid4()) # 为每个文件生成一个唯一的 data_id，或使用其他标识
            # 可以根据需要添加其他参数，如 is_ocr, enable_formula, language, page_ranges 等
            # "is_ocr": False,
            # "enable_formula": True,
            # "language": "ch",
        })

    payload = {
        "files": mineru_files_payload,
        "model_version": "vlm", # 或 "pipeline"，根据需要
        # 可以根据需要添加其他全局参数
        # "enable_formula": True,
        # "enable_table": True,
        # "language": "ch"
    }

    try:
        print(f"INFO: Sending request to {MINERU_BATCH_CREATE_TASK_URL}")
        response = requests.post(MINERU_BATCH_CREATE_TASK_URL, headers=headers, json=payload, timeout=60) # 增加超时时间

        if not response.ok:
            error_data = response.json() if response.headers.get('Content-Type', '').startswith('application/json') else response.text
            print(f"ERROR: MinerU Batch API request failed: {response.status_code} - {error_data}")
            raise Exception(f"MinerU Batch API request failed: {response.status_code} - {error_data}")

        api_response = response.json()
        code = api_response.get("code")
        msg = api_response.get("msg")
        batch_id = api_response.get("data", {}).get("batch_id")

        if code != 0 or not batch_id:
            print(f"ERROR: MinerU Batch API returned error or no batch_id. Code: {code}, Msg: {msg}, Response: {api_response}")
            raise Exception(f"MinerU Batch API error: {msg or 'No batch_id returned'} - {api_response}")

        print(f"INFO: MinerU Batch API task created successfully. Batch ID: {batch_id}")

        # --- 3. 轮询 MinerU 批量任务状态直到完成 ---
        poll_url = f"{MINERU_BATCH_POLL_URL}{batch_id}"
        start_time = time.time()
        while time.time() - start_time < MINERU_MAX_POLL_TIME:
            time.sleep(MINERU_POLL_INTERVAL)
            print(f"INFO: Polling MinerU Batch API for task status (Batch ID: {batch_id})...")

            poll_response = requests.get(poll_url, headers=headers, timeout=60)
            if not poll_response.ok:
                error_data = poll_response.json() if poll_response.headers.get('Content-Type', '').startswith('application/json') else poll_response.text
                print(f"ERROR: MinerU Batch API poll failed: {poll_response.status_code} - {error_data}")
                raise Exception(f"MinerU Batch API poll failed: {poll_response.status_code} - {error_data}")

            poll_data = poll_response.json()
            poll_code = poll_data.get("code")
            poll_msg = poll_data.get("msg")
            poll_batch_id = poll_data.get("data", {}).get("batch_id")
            extract_results = poll_data.get("data", {}).get("extract_result", [])

            if poll_code != 0:
                 print(f"ERROR: MinerU Batch API poll returned error. Code: {poll_code}, Msg: {poll_msg}, Response: {poll_data}")
                 raise Exception(f"MinerU Batch API poll error: {poll_msg or 'Unknown error'} - {poll_data}")

            if poll_batch_id != batch_id:
                print(f"WARNING: Returned batch_id ({poll_batch_id}) does not match requested batch_id ({batch_id})")

            print(f"INFO: Batch {batch_id} status check. Results count: {len(extract_results)}")

            # 检查所有文件的状态
            all_done = True
            any_failed = False
            failed_files = []
            for result in extract_results:
                file_name = result.get("file_name", "Unknown")
                state = result.get("state")
                err_msg = result.get("err_msg", "")
                print(f"INFO: File {file_name} state: {state}")
                if state != "done":
                    all_done = False
                if state == "failed":
                    any_failed = True
                    failed_files.append(f"{file_name}: {err_msg}")

            if any_failed:
                error_msg = f"MinerU Batch API task failed for files: {', '.join(failed_files)}"
                print(f"ERROR: {error_msg}")
                raise Exception(error_msg)

            if all_done:
                # --- 4. 所有任务完成，获取结果 ---
                print(f"INFO: All tasks in batch {batch_id} completed successfully.")

                # --- 5. 创建用户和批次专属的输出目录 ---
                # 使用时间戳和 user_id (或 ANONYMOUS_USER_ID) 作为目录名
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                user_folder_name = f"user_{user_id}_{timestamp}"
                batch_folder_name = f"batch_{batch_id}"
                user_output_dir = os.path.join(app.config['OUTPUTS_FOLDER'], user_folder_name)
                batch_output_dir = os.path.join(user_output_dir, batch_folder_name)
                os.makedirs(batch_output_dir, exist_ok=True) # 创建用户目录和批次目录
                print(f"INFO: Created output directory for user {user_id}, batch {batch_id}: {batch_output_dir}")

                # --- 6. 下载并处理每个成功文件的 ZIP 结果，保存到本地目录 ---
                processed_files_info = []
                generated_reports = []  # <--- 存储 AI 生成的报告

                for result in extract_results:
                    if result.get("state") == "done":
                        file_name = result.get("file_name")
                        full_zip_url = result.get("full_zip_url")
                        if not full_zip_url:
                            print(f"WARNING: No full_zip_url found for file {file_name} in results.")
                            processed_files_info.append({
                                "file_name": file_name,
                                "status": "error",
                                "message": "无法获取解析结果，缺少下载链接。"
                            })
                            continue

                        print(f"INFO: Downloading ZIP for {file_name} from {full_zip_url}")
                        try:
                            zip_response = requests.get(full_zip_url, timeout=60)
                            zip_response.raise_for_status()
                        except requests.exceptions.RequestException as e:
                            print(f"ERROR: Failed to download ZIP for {file_name}: {e}")
                            processed_files_info.append({
                                "file_name": file_name,
                                "status": "error",
                                "message": f"下载解析结果失败: {e}"
                            })
                            continue

                        # 使用内存中的字节流解压 ZIP
                        try:
                            zip_file = zipfile.ZipFile(io.BytesIO(zip_response.content))

                            # 为每个文件创建更短的专属子目录名
                            import re
                            uuid_part_match = re.match(r'^([a-f0-9-]{36})_', file_name)  # 匹配 UUID (36 位带连字符)
                            if uuid_part_match:
                                uuid_part = uuid_part_match.group(1)
                                safe_file_name = uuid_part[:8]  # 取前 8 位作为目录名，非常短
                            else:
                                safe_file_name = re.sub(r'[^\w\-_.]', '_', file_name)[:50]  # 限制长度

                            file_output_subdir = os.path.join(batch_output_dir, safe_file_name)
                            os.makedirs(file_output_subdir, exist_ok=True)
                            print(f"DEBUG: Created file-specific subdir: {file_output_subdir}")  # 调试日志

                            # 遍历 ZIP 文件，提取内容到 *专属子目录* file_output_subdir
                            for name in zip_file.namelist():
                                target_path = os.path.join(file_output_subdir, name)
                                target_path = os.path.normpath(target_path)

                                normalized_target = os.path.normpath(target_path)
                                normalized_base = os.path.normpath(file_output_subdir)
                                if not (normalized_target.startswith(normalized_base) and \
                                        (len(normalized_target) == len(normalized_base) or \
                                         normalized_target[len(normalized_base)] in (os.sep, os.altsep or '/'))):
                                    print(f"WARNING: Invalid path in ZIP for {file_name}: {name}. Skipping.")
                                    continue

                                target_dir = os.path.dirname(target_path)
                                target_dir = os.path.normpath(target_dir)
                                os.makedirs(target_dir, exist_ok=True)

                                if not name.endswith('/'):  # 不是目录
                                    try:
                                        with zip_file.open(name) as source_file:
                                            with open(target_path, 'wb') as target_file:
                                                shutil.copyfileobj(source_file, target_file)
                                        # print(f"INFO: Copied file: {name} -> {target_path}") # <--- 移除：不再打印 INFO 日志
                                    except FileNotFoundError as fnfe:
                                        print(
                                            f"WARNING: Skipped file due to path issue: {name} -> {target_path}")  # <--- 修改为 WARNING，不包含错误详情
                                        # --- 修改结束 ---
                                        continue  # 跳过这个文件
                                    except Exception as e:
                                        print(f"ERROR: Failed to copy ZIP entry '{name}' to '{target_path}': {e}")
                                        raise  # 重新抛出，因为这可能是严重错误
                                else:
                                    pass

                            print(f"INFO: Successfully extracted ZIP contents for {file_name} to {file_output_subdir}")
                            from werkzeug.utils import secure_filename  # 确保在文件顶部导入

                            # ... (analyze_pdf 函数中之前的代码) ...

                            full_md_path = os.path.join(file_output_subdir, "full.md")
                            full_md_path = os.path.normpath(full_md_path)

                            print(
                                f"DEBUG [analyze_pdf]: Checking for full.md existence at: {full_md_path}")  # 调试：检查文件路径
                            if os.path.exists(full_md_path):
                                print(f"DEBUG [analyze_pdf]: full.md found at: {full_md_path}")  # 调试：文件存在
                                # 2. 计算相对于 OUTPUTS_FOLDER 的相对路径
                                relative_md_path = os.path.relpath(full_md_path, app.config['OUTPUTS_FOLDER'])
                                relative_md_path = os.path.normpath(relative_md_path)  # 标准化路径分隔符

                                print(
                                    f"DEBUG [analyze_pdf]: Calculated relative_md_path for {file_name}: {relative_md_path}")

                                # 3. 连接数据库
                                print(
                                    f"DEBUG [analyze_pdf]: Attempting to connect to database to update md_path for {file_name}")  # 调试：连接数据库
                                db_md = SessionLocal()
                                try:
                                    # 4. 查找 Paper 记录
                                    # --- 修改开始：使用 secure_filename 格式化名称后匹配 Paper 记录 ---
                                    print(
                                        f"DEBUG [analyze_pdf]: Querying database for Paper potentially associated with unique_name: '{file_name}'")  # 调试：查询条件
                                    # 从 unique_name 中提取原始文件名部分 (假设格式为 "uuid_original_filename.pdf")
                                    parts = file_name.split('_', 1)  # 只分割一次，得到 uuid 和 rest_of_name
                                    if len(parts) == 2:
                                        extracted_original_filename = parts[1]  # 获取 uuid 后的部分
                                        print(
                                            f"DEBUG [analyze_pdf]: Extracted potential original filename from unique_name '{file_name}': '{extracted_original_filename}'")  # 调试：提取的名称

                                        # --- 修改：使用 secure_filename 格式化提取的文件名 ---
                                        # 这模拟了 add_papers_to_task 中对原始文件名的处理
                                        secure_formatted_filename = secure_filename(extracted_original_filename)
                                        print(
                                            f"DEBUG [analyze_pdf]: Securely formatted filename for DB query: '{secure_formatted_filename}'")  # 调试：格式化后的名称

                                        paper_row = db_md.query(Paper).filter(
                                            Paper.task_id == task_id,
                                            Paper.file_name == secure_formatted_filename).first()
                                        print(f"paper_row is {paper_row}，task_id is {task_id}")
                                        if not paper_row:
                                            pass
                                    else:
                                        # 如果 unique_name 格式不符合预期，直接尝试匹配（不太可能成功，但作为兜底）
                                        print(
                                            f"DEBUG [analyze_pdf]: unique_name '{file_name}' does not match expected 'uuid_original_filename.pdf' format. Attempting direct match on file_name.")  # 调试：格式不符合预期
                                        paper_row = db_md.query(Paper).filter(Paper.file_name == file_name).first()

                                    # --- 修改结束 ---

                                    if paper_row is not None:
                                        print(
                                            f"DEBUG [analyze_pdf]: Found Paper record with ID: {paper_row.id}, task_id: {paper_row.task_id}, file_name: {paper_row.file_name}")  # 调试：找到记录
                                        # 5. 更新 md_path
                                        paper_row.md_path = relative_md_path
                                        print(
                                            f"DEBUG [analyze_pdf]: Updating md_path for Paper ID {paper_row.id} to: {relative_md_path}")  # 调试：更新操作
                                        db_md.commit()  # 提交更改
                                        print(
                                            f"INFO: Successfully updated md_path for Paper ID {paper_row.id} (original file_name in DB: {paper_row.file_name}, analyzed unique_name: {file_name}) to {relative_md_path}")
                                    else:
                                        # 6. 如果 Paper 记录不存在，打印警告
                                        print(
                                            f"DEBUG [analyze_pdf]: Paper record potentially associated with unique_name '{file_name}' (extracted: '{extracted_original_filename if len(parts) == 2 else 'N/A'}', securely formatted for DB: '{secure_formatted_filename if len(parts) == 2 else 'N/A'}') NOT FOUND in database.")  # 调试：未找到记录
                                        print(
                                            f"WARNING [analyze_pdf]: No matching Paper row found for unique_name '{file_name}' (original part: '{extracted_original_filename if len(parts) == 2 else 'N/A'}', formatted: '{secure_formatted_filename if len(parts) == 2 else 'N/A'}') to persist md_path '{relative_md_path}'. Path calculated but not saved to DB yet.")

                                except Exception as e_db:
                                    print(
                                        f"DEBUG [analyze_pdf]: Exception occurred during database operation: {e_db}")  # 调试：数据库异常
                                    db_md.rollback()
                                    print(
                                        f"ERROR [analyze_pdf]: Failed to persist md_path to DB for unique_name '{file_name}': {e_db}")
                                    # 记录错误，但不中断主流程
                                finally:
                                    print(
                                        f"DEBUG [analyze_pdf]: Closing database connection for update attempt on unique_name {file_name}")  # 调试：关闭连接
                                    try:
                                        db_md.close()
                                    except Exception:
                                        pass  # 忽略关闭时的异常
                            else:
                                print(
                                    f"WARNING [analyze_pdf]: full.md not found at expected location: {full_md_path} for unique_name '{file_name}' after extraction.")

                            # --- 7. 读取解析后的 full.md 文件 (现在在专属子目录中) ---
                            full_md_path = os.path.join(file_output_subdir, "full.md")
                            full_md_path = os.path.normpath(full_md_path)
                            if os.path.exists(full_md_path):
                                print(f"INFO: Reading parsed content from {full_md_path}")
                                try:
                                    with open(full_md_path, 'r', encoding='utf-8') as f:
                                        parsed_content = f.read()

                                    # --- 8. 调用 AI 生成导读报告 ---
                                    print(f"INFO: Calling AI to generate report for {file_name}")
                                    ai_system_prompt = "你是一位学术论文解析助手，熟悉论文的结构和内容。请基于用户提供的论文内容生成一份简洁的导读报告，报告应包含论文的核心贡献、主要方法、关键实验设置和主要实验结果。"
                                    ai_user_prompt = f"论文内容：{parsed_content}，请生成一份简洁的导读报告。"

                                    generated_report_content = call_aliyun_api(ai_system_prompt, ai_user_prompt)

                                    if generated_report_content.startswith("Error:"):
                                        print(f"ERROR: AI call failed for {file_name}: {generated_report_content}")
                                        generated_report_content = f"AI 生成报告时出错: {generated_report_content}"

                                    relative_md_path = os.path.relpath(full_md_path, app.config['OUTPUTS_FOLDER'])
                                    relative_md_path = os.path.normpath(relative_md_path)
                                    # 1.9-2255
                                    try:
                                        db_md = SessionLocal()
                                        # 优先精确匹配，其次匹配“UUID_原文件名”形式，最后用 file_path 兜底
                                        paper_row = (
                                            db_md.query(Paper)
                                            .filter(
                                                (Paper.file_name == file_name) |
                                                (Paper.file_name.like(f"%_{file_name}")) |
                                                (Paper.file_path.like(f"%{file_name}"))
                                            )
                                            .order_by(Paper.id.desc())
                                            .first()
                                        )
                                        if paper_row is not None:
                                            paper_row.md_path = relative_md_path
                                            db_md.commit()
                                        else:
                                            print(
                                                f"WARNING: No matching Paper row found to persist md_path for file '{file_name}'.")
                                    except Exception as e:
                                        # 不影响原有解析/AI流程：数据库写入失败仅告警
                                        print(f"WARNING: Failed to persist md_path to DB for file '{file_name}': {e}")
                                    finally:
                                        try:
                                            db_md.close()
                                        except Exception:
                                            pass
                                    # finish
                                    generated_reports.append({
                                        "file_name": file_name,
                                        "report_content": generated_report_content,
                                        "md_path": relative_md_path  # <--- 存储相对路径
                                    })

                                    print(f"INFO: AI report generated for {file_name}")

                                except Exception as e:
                                    print(f"ERROR: Failed to read or process parsed content for {file_name}: {e}")
                                    generated_report_content = f"读取或处理解析结果时出错: {e}"
                                    generated_reports.append({
                                        "file_name": file_name,
                                        "report_content": generated_report_content,
                                        "md_path": ""  # <--- 存储相对路径
                                    })

                            else:
                                print(f"WARNING: full.md not found for {file_name} at {full_md_path}")
                                generated_report_content = f"警告: 未能找到解析后的 full.md 文件。"
                                generated_reports.append({
                                    "file_name": file_name,
                                    "report_content": generated_report_content,
                                    "md_path": ""  # <--- 存储相对路径
                                })

                            processed_files_info.append({
                                "file_name": file_name,
                                "status": "success",
                                "message": "解析结果已保存。",
                                "output_dir": file_output_subdir  # <--- 可选：返回子目录路径
                            })

                        except zipfile.BadZipFile:
                            print(f"ERROR: Downloaded file for {file_name} is not a valid ZIP archive.")
                            processed_files_info.append({
                                "file_name": file_name,
                                "status": "error",
                                "message": "下载的文件不是有效的 ZIP 格式。"
                            })
                        except Exception as e:
                            print(f"ERROR: Failed to process ZIP file for {file_name}: {e}")
                            processed_files_info.append({
                                "file_name": file_name,
                                "status": "error",
                                "message": f"处理解析结果时发生错误: {e}"
                            })

                # --- 9. (可选) 将报告保存到数据库 (当用户点击保存按钮时) ---
                # 本次分析结果保存在本地 outputs 目录，不立即存入数据库
                # 数据库保存逻辑将移到新的 /api/paper/save 接口

                # --- 10. 返回成功响应，包含 AI 生成的报告内容 ---
                # 前端将接收这个报告内容进行预览
                response_data = {
                    "message": f"批量解析完成，成功处理 {len([p for p in processed_files_info if p['status'] == 'success'])} 个文件",
                    "batch_id": batch_id,
                    "successful_files": [p["file_name"] for p in processed_files_info if p["status"] == "success"],
                    "processed_files_info": processed_files_info, # 包含每个文件的处理状态和消息
                    "output_dir": batch_output_dir, # 返回批次输出目录路径，前端需要这个路径来请求内容 (如果需要)
                    "generated_reports": generated_reports, # <--- 新增：返回 AI 生成的报告列表
                }

                return jsonify(response_data)

            # 继续轮询
            continue

        # 如果循环结束仍未完成
        print(f"ERROR: MinerU Batch API task {batch_id} polling timed out after {MINERU_MAX_POLL_TIME} seconds.")
        raise Exception(f"MinerU Batch API task polling timed out after {MINERU_MAX_POLL_TIME} seconds.")

    except requests.exceptions.RequestException as e:
        # 捕获网络请求相关的错误
        print(f"ERROR: Network error during MinerU Batch API call: {str(e)}")
        raise Exception(f"网络错误: {str(e)}")
    except Exception as e:
        # 捕获其他可能的错误
        print(f"ERROR in analyze_pdf (MinerU Batch client): {str(e)}")
        raise # 重新抛出异常，让调用者处理
    finally:
        # --- 11. 清理临时文件 ---
        for temp_path in temp_file_paths:
            if os.path.exists(temp_path):
                os.remove(temp_path)
                print(f"Cleaned up temporary file: {temp_path}")


# --- 新增：提供对 outputs 目录下文件的访问 (带权限验证) ---
@app.route('/api/outputs/<int:user_id>/<path:subpath>')
def get_output_file(user_id, subpath):
    """
    提供对 outputs 目录下特定文件的访问，需验证 user_id。
    前端可以使用此接口获取 Markdown 内容或图片。
    """
    # --- 验证用户权限 ---
    # ... (权限验证逻辑) ...

    # 构造请求的完整路径，防止路径遍历攻击
    # 方案2: 修正路径分隔符问题。subpath 来自 URL，使用 / 分隔符。
    # 使用 os.path.normpath 确保路径在不同系统上都正确。
    subpath_parts = subpath.split('/', 1) # 使用 / 分割 URL 中的路径
    if len(subpath_parts) < 2:
        abort(404)  # subpath 格式不正确，缺少子目录/文件

    actual_user_dir_name = subpath_parts[0]
    remaining_path = subpath_parts[1]

    # 检查实际用户目录名是否符合预期格式 (user_{user_id}_timestamp)
    expected_user_prefix = f"user_{user_id}_"
    if not actual_user_dir_name.startswith(expected_user_prefix):
        abort(403)  # Forbidden - 尝试访问不属于该 user_id 的目录

    requested_path = os.path.join(app.config['OUTPUTS_FOLDER'], actual_user_dir_name, remaining_path)
    # 规范化路径，处理可能的 ../ 等情况，确保路径安全
    requested_path = os.path.normpath(requested_path)

    # 确保请求的路径在 outputs 目录内，防止路径遍历攻击
    if not requested_path.startswith(os.path.normpath(app.config['OUTPUTS_FOLDER'])):
        abort(403)  # Forbidden

    print(f"DEBUG: Looking for file at: {requested_path}") # 添加调试日志
    if not os.path.exists(requested_path):
        print(f"DEBUG: File does not exist: {requested_path}") # 添加调试日志
        abort(404)  # Not Found

    # 安全检查：只允许访问特定类型的文件
    allowed_extensions = {'.md', '.jpg', '.jpeg', '.png', '.gif', '.svg', '.json', '.pdf'} # 根据需要添加
    _, ext = os.path.splitext(requested_path)
    if ext.lower() not in allowed_extensions:
        abort(403)  # Forbidden

    # 返回文件
    return send_from_directory(os.path.dirname(requested_path), os.path.basename(requested_path))


# 保存报告接口（核心）
@app.route('/api/report/create', methods=['POST'])
def create_report_api():
    """
    保存 AI 生成的报告到数据库
    """
    # --- 修改：检查 Content-Type 并相应处理 ---
    content_type = request.content_type
    if content_type and content_type.startswith('application/json'):
        data = request.get_json(force=True)
        user_id_str = data.get("user_id")
        title = data.get("title", "").strip()
        content = data.get("content", "")
        # <--- 新增：获取 task_id 参数 --->
        task_id_str = data.get("task_id") # 获取 task_id，可能为 None
        task_id = int(task_id_str) if task_id_str and task_id_str.isdigit() else None
        # <--- 新增结束 --->
    elif content_type and content_type.startswith('multipart/form-data'):
        user_id_str = request.form.get('user_id')
        title = request.form.get('title', '').strip()
        content = request.form.get('content', '')
        # <--- 修改：获取 task_id 参数 --->
        task_id_str = request.form.get('task_id') # 获取 task_id，可能为 None
        task_id = int(task_id_str) if task_id_str and task_id_str.isdigit() else None
        # <--- 修改结束 --->
    elif content_type and content_type.startswith('application/x-www-form-urlencoded'):
        user_id_str = request.form.get('user_id')
        title = request.form.get('title', '').strip()
        content = request.form.get('content', '')
        task_id_str = request.form.get('task_id')
        task_id = int(task_id_str) if task_id_str and task_id_str.isdigit() else None
    else:
        print(f"DEBUG: Unsupported Content-Type: {content_type}")
        return jsonify({"error": f"Unsupported Content-Type: {content_type}"}), 415

    # --- 参数校验 ---
    if not user_id_str or not title or not content:
        print(f"DEBUG: Missing required fields in form data. user_id_str: '{user_id_str}', title: '{title}', content (first 100 chars): '{content[:100]}...'") # 添加调试日志
        return jsonify({"error": "缺少必要参数 (user_id, title, content)"}), 400

    try:
        user_id = int(user_id_str)
    except ValueError:
        print(f"DEBUG: Invalid user_id format received: '{user_id_str}'") # 添加调试日志
        return jsonify({"error": "user_id 必须是整数"}), 400

    db = SessionLocal()
    try:
        # <--- 修改：将 task_id 传递给 create_report 函数 --->
        report = create_report(
            db_session=db,
            owner_id=user_id,
            title=title,
            content=content,
            task_id=task_id # <--- 传递 task_id
        )
        return jsonify({
            "message": "报告保存成功",
            "report_id": report.id
        }), 201
    except Exception as e:
        db.rollback()
        app.logger.error(f"保存报告失败: {str(e)}", exc_info=True)
        return jsonify({"error": f"保存报告失败: {str(e)}"}), 500
    finally:
        db.close()



#获取我的报告列表
@app.route('/api/reports', methods=['GET'])
def list_my_reports():
    """
    获取当前用户的报告列表
    """
    user_id = request.args.get('user_id')
    if not user_id:
        return jsonify({"error": "缺少 user_id"}), 400

    db = SessionLocal()
    try:
        reports = get_reports_by_owner(db, int(user_id))
        return jsonify([
            {
                "id": r.id,
                "title": r.title,
                "created_at": r.created_at.isoformat()
            }
            for r in reports
        ])
    finally:
        db.close()


# =========================================================
# ⑧ 报告下载接口（Markdown 文件） - 修正：保留一个版本
# GET /api/report/<report_id>/download
# =========================================================
@app.route('/api/report/<int:report_id>/download', methods=['GET'])
def download_report(report_id):
    """
    下载指定报告（Markdown 文件）
    """
    db = SessionLocal()
    try:
        report = get_report_by_id(db, report_id)
        if not report:
            return jsonify({"error": "报告不存在"}), 404

        # 报告内容是 bytes，解码成字符串
        content_str = report.content.decode('utf-8')
        filename = f"{report.title}.md"

        temp_dir = tempfile.mkdtemp()
        file_path = os.path.join(temp_dir, filename)

        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(content_str)

        return send_from_directory(
            temp_dir,
            filename,
            as_attachment=True
        )
    finally:
        db.close()


# ======================================================
# ④ 创建导读任务（工程级实现）
# ======================================================
# main/app.py
@app.route('/api/task/create', methods=['POST'])
def create_task_api():
    """
    创建一个新的导读任务（Task）
    """
    # --- 修改：检查请求类型并相应处理 ---
    print("ready to create a new task")
    print(f"DEBUG: Request Method: {request.method}")
    print(f"DEBUG: Request Content-Type: {request.content_type}")
    print(f"DEBUG: Request Headers: {dict(request.headers)}")
    print(f"DEBUG: Request Args (Query Params): {request.args}")
    print(f"DEBUG: Raw Form Data Keys: {list(request.form.keys())}")  # 打印 form 数据的键
    content_type = request.content_type
    if content_type and content_type.startswith('application/json'):
        # 处理 JSON 请求体
        data = request.get_json(force=True)
        user_id_str = data.get("user_id")
        title = data.get("title", "").strip()
        print(f"user_id = {user_id_str}, title = {title}")
    elif content_type and content_type.startswith('multipart/form-data'):
        # 处理 FormData 请求体 (例如通过 fetch 发送的 FormData)
        # 注意：FormData 通常用于文件上传，但也可以包含普通字段
        # request.form 用于获取 FormData 中的普通字段
        user_id_str = request.form.get('user_id')  # <--- 从 form 获取
        title = request.form.get('title', '').strip()  # <--- 从 form 获取
    elif content_type and content_type.startswith('application/x-www-form-urlencoded'):
        # 处理 application/x-www-form-urlencoded 请求体 (例如传统的表单提交)
        user_id_str = request.form.get('user_id')
        title = request.form.get('title', '').strip()
    else:
        # 如果 Content-Type 不是预期的类型，返回错误
        print(f"DEBUG: Unsupported Content-Type: {content_type}") # 调试日志
        return jsonify({"error": f"Unsupported Content-Type: {content_type}"}), 415 # 415 Unsupported Media Type

    # --- 参数校验 ---
    if not user_id_str or not title:
        print(f"DEBUG: Missing required fields in request. user_id_str: '{user_id_str}', title: '{title}'") # 添加调试日志
        return jsonify({"error": "缺少必要参数 (user_id, title)"}), 400

    try:
        user_id = int(user_id_str)
    except ValueError:
        print(f"DEBUG: Invalid user_id format received: '{user_id_str}'") # 添加调试日志
        return jsonify({"error": "user_id 必须是整数"}), 400

    db = SessionLocal()
    try:
        task = create_task(
            db=db,
            user_id=user_id,
            title=title
        )
        return jsonify({
            "task_id": task.id,
            "title": task.title,
            "status": task.status,
            "paper_count": task.paper_count,
            "created_at": task.created_at.isoformat()
        }), 201
    except Exception as e:
        db.rollback()
        app.logger.error(f"创建导读任务失败: {str(e)}", exc_info=True) # 添加 exc_info=True 以获取完整堆栈跟踪
        return jsonify({"error": "创建导读任务失败"}), 500
    finally:
        db.close()




# --- 新增获取任务列表接口 ---
@app.route('/api/tasks', methods=['GET'])
def api_list_tasks():
    """
    获取用户任务列表
    """
    user_id_str = request.args.get('user_id') # 获取 user_id 参数，可能为 None

    if not user_id_str or user_id_str == 'undefined': # <--- 检查是否为 None 或 'undefined'
        return jsonify({"error": "缺少或无效的 user_id 参数"}), 400

    try:
        user_id = int(user_id_str) # 尝试转换为整数
    except ValueError:
        # 如果转换失败，说明参数不是有效的数字字符串
        return jsonify({"error": f"无效的 user_id 参数: {user_id_str}"}), 400

    db = SessionLocal()
    try:
        tasks = get_tasks_by_user(db, user_id)
        return jsonify(tasks)
    except Exception as e:
        app.logger.error(f"获取任务列表失败: {str(e)}", exc_info=True)
        return jsonify({"error": f"获取任务列表失败: {str(e)}"}), 500
    finally:
        db.close()



# ======================================================
# ③ 获取单个导读任务详情（任务 → 多论文）
# ======================================================
@app.route('/api/task/<int:task_id>', methods=['GET'])
def get_task_detail(task_id):
    """
    获取单个导读任务的详细信息：
    - 任务基本信息
    - 该任务下的所有论文列表
    """
    db = SessionLocal()
    try:
        # 查询任务
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            return jsonify({"error": "导读任务不存在"}), 404

        # 构造论文列表
        papers_data = []
        for paper in task.papers:
            papers_data.append({
                "id": paper.id,
                "title": paper.title,
                "file_name": paper.file_name,
                "upload_time": paper.upload_time.isoformat()
            })

        # 返回任务 + 论文
        return jsonify({
            "task": {
                "id": task.id,
                "title": task.title,
                "status": task.status,
                "paper_count": task.paper_count,
                "created_at": task.created_at.isoformat(),
                "updated_at": task.updated_at.isoformat()
            },
            "papers": papers_data
        })
    except Exception as e:
        app.logger.error(f"获取导读任务详情失败: {str(e)}")
        return jsonify({"error": "获取导读任务详情失败"}), 500
    finally:
        db.close()


@app.route('/api/task/<int:task_id>/papers', methods=['GET', 'POST'])  # 同时处理 GET 和 POST
def add_papers_to_task(task_id):
    """
    GET: 获取指定任务下的所有论文列表 (包含内容或路径)
    POST: 向指定导读任务中上传并添加论文（PDF）
    """
    # --- 区分请求方法 ---
    if request.method == 'GET':
        # --- GET 请求：获取论文列表 ---
        db = SessionLocal()
        try:
            # 从数据库查询 task_id 对应的所有论文
            papers = db.query(Paper).filter(Paper.task_id == task_id).all()

            # 构造返回给前端的 JSON 列表
            paper_list = []
            for p in papers:
                # 如果需要返回内容，可以读取 md_path 指向的文件
                content_str = ""
                if p.md_path:
                    full_path = os.path.join(app.config['OUTPUTS_FOLDER'], p.md_path)
                    if os.path.exists(full_path):
                        try:
                            with open(full_path, 'r', encoding='utf-8') as f:
                                content_str = f.read()
                        except Exception as e:
                            print(f"Error reading file {full_path}: {e}")
                            content_str = f"Error reading file: {e}"
                    else:
                        print(f"File not found: {full_path}")
                        content_str = f"File not found: {p.md_path}"
                # 如果 Paper 表有 content 字段，也可以直接使用 (注意解码)
                # content_str = p.content.decode('utf-8') if isinstance(p.content, bytes) else p.content

                paper_list.append({
                    "id": p.id,
                    "title": p.title,
                    "file_name": p.file_name,
                    "content": content_str, # 返回内容
                    # "md_path": p.md_path, # 或者返回路径，由前端请求
                })

            return jsonify(paper_list)
        except Exception as e:
            app.logger.error(f"获取任务 {task_id} 的论文列表失败: {str(e)}", exc_info=True)
            return jsonify({"error": f"获取论文列表失败: {str(e)}"}), 500
        finally:
            db.close()

    elif request.method == 'POST':
        # --- POST 请求：上传论文 ---
        # ---- 校验文件 ----
        if 'files' not in request.files:
            return jsonify({"error": "未检测到上传文件"}), 400

        files = request.files.getlist('files')
        if not files or len(files) == 0:
            return jsonify({"error": "文件列表为空"}), 400

        db = SessionLocal()
        saved_papers = []
        try:
            # ---- 校验任务是否存在 ----
            task = get_task_by_id(db, task_id) # <--- 调用不带 with_papers 参数的函数
            if not task:
                return jsonify({"error": "导读任务不存在"}), 404

            # ---- 为该任务创建专属目录 ----
            task_dir = os.path.join(
                app.config['UPLOAD_FOLDER'],
                f"task_{task_id}"
            )
            os.makedirs(task_dir, exist_ok=True)

            # ---- 逐个保存文件 ----
            for file in files:
                if file.filename == '':
                    continue
                filename = secure_filename(file.filename)
                if not filename.lower().endswith('.pdf'):
                    continue

                unique_name = f"{uuid.uuid4().hex}_{filename}"
                file_path = os.path.join(task_dir, unique_name)

                # 保存文件到磁盘
                file.save(file_path)

                # 论文标题：优先用前端传的，否则用文件名
                paper_title = request.form.get('title') or filename

                # 写入数据库
                paper = add_paper_to_task(
                    db=db,
                    task_id=task_id,
                    file_name=filename,
                    file_path=file_path, # <--- 保存的是上传的原始 PDF 路径
                    title=paper_title
                )
                saved_papers.append({
                    "paper_id": paper.id,
                    "file_name": paper.file_name
                })

            if len(saved_papers) == 0:
                return jsonify({"error": "未成功保存任何论文文件"}), 400

            return jsonify({
                "message": "论文上传成功",
                "task_id": task_id,
                "papers": saved_papers
            }), 201
        except Exception as e:
            db.rollback()
            app.logger.error(f"上传论文失败: {str(e)}")
            return jsonify({"error": "上传论文失败"}), 500
        finally:
            db.close()


# --- 以下是原有接口，保持不变 ---
@app.route('/api/ai/ask', methods=['POST'])
def ask_ai():
    """
    处理AI提问请求
    该接口现在调用 core/ai_analyzer.py 中已有的功能
    """
    data = request.json
    question = data.get('question', '').strip()
    context = data.get('context', '').strip() # 获取前端发送的 Markdown 内容

    if not question:
        return jsonify({"error": "问题不能为空"}), 400

    if not context:
        return jsonify({"error": "上下文内容不能为空"}), 400

    # --- 添加调试信息 ---
    print(f"DEBUG: Received question: {question}")
    print(f"DEBUG: Received context length: {len(context)}")
    print(f"DEBUG: Received context preview: {context[:200]}...") # 打印前200个字符
    # --- 添加调试信息结束 ---

    try:
        # 将 context 放在 user_prompt 中，与 question 结合
        user_prompt_with_context = f"论文内容：\n\n{context}\n\n问题：{question}"

        # system_prompt 专注于角色和任务定义
        system_prompt = "你是一位学术论文解析助手，熟悉论文的结构和内容。请基于用户提供的论文内容回答其问题。"

        print(f"DEBUG: Final system_prompt: {system_prompt}")  # 添加这行
        print(f"DEBUG: Final user_prompt_with_context length: {len(user_prompt_with_context)}")  # 添加这行
        print(f"DEBUG: Final user_prompt_with_context preview: {user_prompt_with_context[:200]}...")  # 添加这行

        answer = call_aliyun_api(system_prompt, user_prompt_with_context)

        # 检查是否返回了错误
        if answer.startswith("Error:"):
            return jsonify({"error": f"AI服务调用失败: {answer}"}), 500

        return jsonify({"answer": answer})

    except Exception as e:
        app.logger.error(f"AI请求失败: {str(e)}")
        return jsonify({"error": f"服务暂时不可用: {str(e)}"}), 500


# --- 以下是新增的、更符合你现有模块功能的接口 ---
@app.route('/api/ai/analyze_text_block', methods=['POST'])
def analyze_text_block_endpoint():
    """
    分析单个文本块的标签（method, experiment setting, main experiment result）
    """
    data = request.json
    content = data.get('content', '').strip()

    if not content:
        return jsonify({"error": "文本内容不能为空"}), 400

    try:
        label = analyze_text_block(content)
        if label.startswith("Error:"):
            return jsonify({"error": f"分析失败: {label}"}), 500
        return jsonify({"label": label})
    except Exception as e:
        app.logger.error(f"文本块分析失败: {str(e)}")
        return jsonify({"error": f"分析服务暂时不可用: {str(e)}"}), 500


@app.route('/api/ai/summarize_method', methods=['POST'])
def summarize_method_endpoint():
    """
    总结方法部分的文本
    """
    data = request.json
    method_text = data.get('method_text', '').strip()

    if not method_text:
        return jsonify({"error": "方法文本不能为空"}), 400

    try:
        summary = summarize_method(method_text)
        if summary.startswith("Error:"):
            return jsonify({"error": f"总结失败: {summary}"}), 500
        return jsonify({"summary": summary})
    except Exception as e:
        app.logger.error(f"方法总结失败: {str(e)}")
        return jsonify({"error": f"总结服务暂时不可用: {str(e)}"}), 500


# =========================================================
# ⑥ 任务级 AI 分析接口（核心） - 修正版
# POST /api/task/<task_id>/analyze
# =========================================================
@app.route("/api/task/<int:task_id>/analyze", methods=["POST"])
def analyze_task(task_id: int):
    """
    对指定导读任务下的所有论文（基于其解析结果）执行 AI 分析，
    并生成一个任务级导读报告。
    """
    db = SessionLocal()
    try:
        # 1. 查任务及其论文
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            return jsonify({"error": "导读任务不存在"}), 404

        if not task.papers or len(task.papers) == 0:
            return jsonify({"error": "该任务下暂无论文"}), 400

        # 2. 更新任务状态
        task.status = "processing"
        db.commit()

        # 3. 逐篇论文分析 (基于解析结果)
        paper_summaries = []
        for paper in task.papers:
            # --- 修正：查找对应的解析结果文件 ---
            # 假设 Paper.md_path 存储了 full.md 的相对路径，或者我们需要从 outputs 目录结构推断
            # 方案A: 如果 Paper.md_path 存在且有效
            # md_file_path = os.path.join(app.config['OUTPUTS_FOLDER'], paper.md_path) if paper.md_path else None
            # 方案B: 根据 outputs 目录结构推断 (需要知道 paper 对应的 batch_id 或其他信息)
            # 这比较困难，因为 paper.file_path 是原始 PDF 路径。
            # 方案C: 假设 paper.task_id 可以帮助定位 outputs 目录下的 batch 文件夹
            # 这需要 Paper 模型包含更多解析后的路径信息，或者任务执行后能关联起来。
            # 最简单的方案是：在 analyze_pdf 成功后，创建 Paper 时，同时将解析结果的路径信息（如 batch_output_dir）与 Paper 关联。
            # 但当前 Paper 模型没有存储解析后的路径。
            # 临时方案：假设 paper.file_path 中的文件名 (不含扩展名) 对应 outputs 目录下某个 batch 中的 full.md
            # 这需要 paper.file_path 指向解析后的 full.md，这不符合当前设计。
            # 更合理的方案：在 Paper 模型中增加一个字段，例如 parsed_md_path，指向解析后的 full.md 文件。
            # 或者，在 Task 执行解析时，记录 batch_id，并将 Paper 与该 batch_id 关联。

            # 这里采用一个假设：Paper 模型中有一个字段 `md_path` 存储了解析后 Markdown 的相对路径。
            # 如果 `md_path` 不存在或为空，则尝试根据 `file_name` 推断。
            # **重要**：这需要在 `analyze_pdf` 成功后，将解析结果的路径信息（如 batch_output_dir/full.md）与 Paper 关联。
            # 例如，在 `analyze_pdf` 的 `processed_files_info` 成功后，创建 Paper 时设置 `md_path`。
            # 这里我们假设 `paper.md_path` 已经被正确设置，指向 `outputs` 目录下的 `full.md` 文件。
            # 如果没有设置，则需要一种方式来找到对应的 `full.md`。

            # **实现方式1：假设 Paper.md_path 已设置**
            md_file_path = None
            if paper.md_path:
                 md_file_path = os.path.join(app.config['OUTPUTS_FOLDER'], paper.md_path)

            # **实现方式2：尝试根据 task 和 paper 文件名推断 (不推荐，耦合性强)**
            # if not md_file_path:
            #     # 需要一种方式找到 task 对应的 batch_output_dir
            #     # 这可能需要在 Task 模型中存储 batch_id 或 output_dir 信息
            #     # 或者，遍历 outputs 目录下 user_{task.user_id}_* 下的 batch_*
            #     # 这个逻辑比较复杂且脆弱。

            # **实现方式3：最简单，假设 full.md 位于 paper.file_path 所在的目录下 (错误的假设)**
            # md_file_path = os.path.join(os.path.dirname(paper.file_path), 'full.md') # 错误！

            # **实现方式4：最健壮，需要修改流程**
            # 在 `analyze_pdf` 流程中，当解压 ZIP 后，创建 Paper 记录时，同时设置 `md_path`。
            # 例如，在 `analyze_pdf` 成功处理完一个 PDF 后，调用 `add_paper_to_task` 时，
            # 将 `md_path` 参数传入，值为相对于 OUTPUTS_FOLDER 的路径，如 "user_999_.../batch_.../full.md"。
            # 这样，这里的 `paper.md_path` 就是有效的。

            # 基于以上分析，我们假设 `paper.md_path` 已被正确设置。
            if not md_file_path or not os.path.exists(md_file_path):
                 print(f"WARNING: Cannot find Markdown file for paper {paper.id} ({paper.file_name}). Skipping analysis.")
                 continue # 跳过此论文

            # 读取解析后的 Markdown 内容
            try:
                with open(md_file_path, "r", encoding="utf-8") as f:
                    raw_content = f.read()
            except Exception as e:
                 print(f"ERROR: Failed to read Markdown file {md_file_path} for paper {paper.id}. Error: {e}")
                 continue # 跳过此论文

            # 调用你已有的 AI 分析逻辑（示例：对全文进行总结）
            # 注意：这里直接对全文分析可能不是最佳策略，可以先分块再分析。
            analysis_prompt = f"请分析以下论文的核心贡献与方法：\n\n{raw_content[:8000]}" # 控制输入长度
            analysis_result = call_aliyun_api(system_prompt="", user_prompt=analysis_prompt) # system_prompt 为空，因为 prompt 里已包含指令

            paper_summaries.append({
                "paper_id": paper.id,
                "title": paper.title or paper.file_name,
                "analysis": analysis_result
            })

        if len(paper_summaries) == 0:
            task.status = "failed"
            db.commit()
            return jsonify({"error": "所有论文均无法分析或未找到解析结果"}), 500

        # 4. 汇总生成导读报告（Markdown）
        report_md = f"# 导读报告：{task.title}\n\n"
        report_md += f"## 论文数量：{len(paper_summaries)}\n\n"
        for idx, item in enumerate(paper_summaries, start=1):
            report_md += f"### 论文 {idx}：{item['title']}\n\n"
            report_md += item["analysis"] + "\n\n"

        # （可选）结构化报告生成 - 需要先对内容进行分块和标记
        # structured_analysis_results = []
        # for item in paper_summaries:
        #     # 这里需要将 item['analysis'] 或原始 raw_content 再次分块标记
        #     # 然后组织成 analysis_results 格式
        #     pass
        # report_md = generate_structured_report(structured_analysis_results)

        # 5. 保存导读报告到数据库
        report = create_report(
            db_session=db,
            owner_id=task.user_id, # 报告属于任务的创建者
            title=f"导读任务报告 - {task.title}",
            content=report_md
        )

        # 6. 更新任务状态
        task.status = "done"
        db.commit()

        return jsonify({
            "message": "导读任务分析完成",
            "task_id": task.id,
            "report_id": report.id
        }), 200

    except Exception as e:
        db.rollback()
        if "task" in locals() and task: # 确保 task 变量存在且不为 None
            task.status = "failed"
            db.commit()
        app.logger.error(f"任务分析失败: {str(e)}", exc_info=True)
        return jsonify({"error": "任务分析失败"}), 500
    finally:
        db.close()


# =========================================================
# ⑦ 任务级多论文 AI 问答 / 对比分析接口 - 修正版
# POST /api/task/<task_id>/qa
# =========================================================
@app.route("/api/task/<int:task_id>/qa", methods=["POST"])
def task_multi_paper_qa(task_id: int):
    """
    基于导读任务下的多篇论文（基于其解析结果）进行 AI 问答或对比分析
    """
    data = request.get_json(force=True)
    question = data.get("question", "").strip()

    if not question:
        return jsonify({"error": "问题不能为空"}), 400

    db = SessionLocal()
    try:
        # 1. 查任务与论文
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            return jsonify({"error": "导读任务不存在"}), 404

        if not task.papers or len(task.papers) == 0:
            return jsonify({"error": "该任务下暂无论文"}), 400

        # 2. 读取论文的解析后内容（构造上下文）
        paper_contexts = []
        for paper in task.papers:
            # --- 修正：查找对应的解析结果文件 ---
            # 同 analyze_task，需要 paper.md_path 或其他方式找到 full.md
            md_file_path = None
            if paper.md_path:
                 md_file_path = os.path.join(app.config['OUTPUTS_FOLDER'], paper.md_path)

            if not md_file_path or not os.path.exists(md_file_path):
                 print(f"WARNING: Cannot find Markdown file for paper {paper.id} ({paper.file_name}). Skipping for QA.")
                 continue # 跳过此论文

            try:
                with open(md_file_path, "r", encoding="utf-8") as f:
                    raw_content = f.read()
            except Exception as e:
                 print(f"ERROR: Failed to read Markdown file {md_file_path} for paper {paper.id}. Error: {e}")
                 continue # 跳过此论文

            paper_contexts.append({
                "title": paper.title or paper.file_name,
                "content": raw_content[:6000]  # 控制上下文长度，避免 token 过多
            })

        if len(paper_contexts) == 0:
            return jsonify({"error": "无法读取任何论文的解析内容"}), 500

        # 3. 构造对比 Prompt
        prompt = (
            "你是一个学术助理，需要基于多篇论文进行综合分析和对比。\n"
            "以下是多篇论文的内容摘要：\n\n"
        )
        for idx, paper in enumerate(paper_contexts, start=1):
            prompt += f"【论文 {idx}：{paper['title']}】\n"
            prompt += paper["content"]
            prompt += "\n\n"

        prompt += (
            "请基于上述论文内容，回答以下问题。\n"
            "如果是对比问题，请明确指出不同论文的差异与共性。\n\n"
            f"问题：{question}\n"
        )

        # 4. 调用你已有的 AI 接口
        answer = call_aliyun_api(system_prompt="", user_prompt=prompt) # system_prompt 为空，因为 prompt 里已包含指令

        return jsonify({
            "task_id": task.id,
            "question": question,
            "answer": answer
        }), 200

    except Exception as e:
        app.logger.error(f"任务级问答失败: {str(e)}", exc_info=True)
        return jsonify({"error": "任务级问答失败"}), 500
    finally:
        db.close()


# =========================================================
# ⑨ 任务级结构化报告生成接口 - 修正版
# POST /api/task/<task_id>/structured-analyze
# =========================================================
@app.route("/api/task/<int:task_id>/structured-analyze", methods=["POST"])
def structured_analyze_task(task_id: int):
    """
    为导读任务下的论文（基于其解析结果）生成结构化解析结果（分块）并存储到 ParsedBlock 表。
    """
    db = SessionLocal()
    try:
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            return jsonify({"error": "任务不存在"}), 404

        if not task.papers:
            return jsonify({"error": "任务下暂无论文"}), 400

        results = []
        for paper in task.papers:
            # --- 修正：查找对应的解析结果文件 ---
            md_file_path = None
            if paper.md_path:
                 md_file_path = os.path.join(app.config['OUTPUTS_FOLDER'], paper.md_path)

            if not md_file_path or not os.path.exists(md_file_path):
                 print(f"WARNING: Cannot find Markdown file for paper {paper.id} ({paper.file_name}). Skipping structured analysis.")
                 continue # 跳过此论文

            try:
                with open(md_file_path, "r", encoding="utf-8") as f:
                    raw_content = f.read()
            except Exception as e:
                 print(f"ERROR: Failed to read Markdown file {md_file_path} for paper {paper.id}. Error: {e}")
                 continue  # 跳过此论文

            # --- 修正：实现结构化分析逻辑 ---
            # 1. 分割 Markdown 内容
            content_blocks = split_markdown_content(raw_content)

            # 2. 对每个块进行分析和标记
            parsed_blocks_data = []
            for i, block in enumerate(content_blocks):
                if not block.strip():  # 跳过空块
                    continue
                # 调用 analyze_text_block 获取标签
                label = analyze_text_block(block)
                if label.startswith("Error:"):
                    print(f"Warning: Failed to label block {i} for paper {paper.id}: {label}")
                    continue # 跳过此块

                # 3. 保存到 ParsedBlock 表
                parsed_block = create_parsed_block(
                    db_session=db,
                    paper_id=paper.id,
                    block_type=label,
                    content=block,
                    section_index=i  # 可选：记录在原论文中的顺序
                )
                parsed_blocks_data.append(parsed_block.id)

            results.append({
                "paper_id": paper.id,
                "title": paper.title or paper.file_name,
                "block_count": len(parsed_blocks_data),
                "parsed_block_ids": parsed_blocks_data # 返回创建的块ID列表
            })

        # 可选：更新任务状态
        # task.status = "structured_analysis_done" # 或者一个新的状态
        # db.commit()

        return jsonify({
            "message": "结构化解析完成",
            "task_id": task.id,
            "results": results
        }), 200

    except Exception as e:
        db.rollback()
        app.logger.error(f"结构化分析失败: {str(e)}", exc_info=True)
        return jsonify({"error": "结构化分析失败"}), 500
    finally:
        db.close()


# --- 在现有路由之后添加新的保存任务路由 ---
@app.route('/api/task/save-current', methods=['POST'])
def save_current_analysis_as_task():
    """
    将当前分析/编辑的内容保存为一个新任务。
    这个任务包含一个关联的报告。
    """
    # --- 修改：使用 request.form 而不是 request.get_json ---
    user_id_str = request.form.get('user_id')
    task_title = request.form.get('title', '').strip()
    content = request.form.get('content', '') # 获取前端发送的当前内容

    if not user_id_str or not task_title or not content:
        print(f"DEBUG: Missing required fields in form data. user_id_str: '{user_id_str}', title: '{task_title}', content (first 100 chars): '{content[:100]}...'") # 添加调试日志
        return jsonify({"error": "缺少必要参数 (user_id, title, content)"}), 400

    try:
        user_id = int(user_id_str)
    except ValueError:
        print(f"DEBUG: Invalid user_id format received: '{user_id_str}'") # 添加调试日志
        return jsonify({"error": "user_id 必须是整数"}), 400

    db = SessionLocal()
    try:
        # 1. 创建 Task 记录
        task = create_task(db, user_id=user_id, title=task_title)
        print(f"INFO: Created Task with ID: {task.id}")

        # 2. 将内容作为 Report 与 Task 关联
        report_title = f"报告_{task_title}"
        report = create_report(
            db_session=db,
            owner_id=user_id,
            title=report_title,
            content=content,
            task_id=task.id # 关联到新创建的任务
        )
        print(f"INFO: Created Report with ID: {report.id}, linked to Task ID: {task.id}")

        db.commit()

        return jsonify({
            "message": "任务保存成功",
            "task_id": task.id,
            "report_id": report.id
        }), 201

    except Exception as e:
        db.rollback()
        app.logger.error(f"保存任务失败: {str(e)}", exc_info=True)
        return jsonify({"error": f"保存任务失败: {str(e)}"}), 500
    finally:
        db.close()


@app.route('/api/task/<int:task_id>/reports', methods=['GET'])
def get_reports_by_task(task_id):
    """
    获取指定任务下的所有报告列表
    """
    db = SessionLocal()
    try:
        # 从数据库查询 task_id 对应的所有报告
        # 确保 Report 模型中的 task_id 字段存在且类型匹配 (int)
        reports = db.query(Report).filter(Report.task_id == task_id).all()

        # 构造返回给前端的 JSON 列表
        report_list = []
        for r in reports:
             # 如果 content 是 bytes 类型 (在 create_report 中被编码)，需要解码
             content_str = r.content.decode('utf-8') if isinstance(r.content, bytes) else r.content
             report_list.append({
                 "id": r.id,
                 "title": r.title,
                 # "content": content_str,  # 注意：通常列表接口不返回完整内容，以提高性能
                 "content_preview": content_str[:100] + "..." if len(content_str) > 100 else content_str, # 返回内容预览
                 "created_at": r.created_at.isoformat()
             })

        return jsonify(report_list)
    except Exception as e:
        app.logger.error(f"获取任务 {task_id} 的报告列表失败: {str(e)}", exc_info=True)
        return jsonify({"error": f"获取报告列表失败: {str(e)}"}), 500
    finally:
        db.close()



@app.route('/api/task/<int:task_id>', methods=['DELETE'])
def delete_task(task_id):
    """
    删除指定 ID 的任务及其关联的论文和报告 (通过 cascade 约束)
    """
    db = SessionLocal()
    try:
        # 查询任务
        task = db.query(Task).filter(Task.id == task_id).first()
        if not task:
            return jsonify({"error": "任务不存在"}), 404

        # 删除任务 (关联的 Paper, ParsedBlock, Report 会因 cascade 约束被自动删除)
        db.delete(task)
        db.commit()

        return jsonify({"message": f"任务 {task_id} 及其关联数据删除成功"}), 200

    except Exception as e:
        db.rollback()
        app.logger.error(f"删除任务 {task_id} 失败: {str(e)}", exc_info=True)
        return jsonify({"error": f"删除任务失败: {str(e)}"}), 500
    finally:
        db.close()


@app.route('/api/task/<int:task_id>/compare', methods=['POST'])
def compare_papers_in_task(task_id):
    """
    对指定任务下的论文进行对比分析
    """
    data = request.get_json(force=True)
    comparison_prompt = data.get("prompt", "").strip()

    if not comparison_prompt:
        return jsonify({"error": "缺少必要参数 (prompt)"}), 400

    db = SessionLocal()
    try:
        # 从数据库查询 task_id 对应的所有论文
        papers = db.query(Paper).filter(Paper.task_id == task_id).all()

        if not papers:
            return jsonify({"error": f"任务 {task_id} 下无论文可进行对比"}), 404

        paper_contents = []
        for p in papers:
             # --- 修改开始：检查 p.md_path 是否为 None ---
             if p.md_path is None:
                 print(f"WARNING: Paper {p.id} (file_name: {p.file_name}) has a NULL md_path. Skipping.")
                 # 可以选择跳过这个论文，或者返回错误
                 # Option 1: Skip
                 continue
                 # Option 2: Return error (uncomment the next line)
                 # return jsonify({"error": f"论文 {p.file_name} 的路径信息缺失，无法进行对比。"}), 400
             # --- 修改结束 ---

             # --- 修改：使用 Paper.md_path 构造完整路径 ---
             # 假设 p.md_path 是 "user_1_20260109_125754/batch_87554b71-3d3a-463b-8962-dc403ec2352e/4b3e2e58-214f-4438-8bc1-406635e6b2fc_AnomalyControl_Learning_Cross-modal_Semantic_Features_for_Controllable_Anomaly_Synthesis.pdf/full.md"
             full_path = os.path.join(app.config['OUTPUTS_FOLDER'], p.md_path) # <--- 使用存储的相对路径
             # --- 修改结束 ---
             if os.path.exists(full_path):
                 try:
                     with open(full_path, 'r', encoding='utf-8') as f:
                         content_str = f.read()
                     paper_contents.append(content_str)
                 except Exception as e:
                     print(f"Error reading file {full_path}: {e}")
                     paper_contents.append(f"Error reading file: {e}")
             else:
                 print(f"File not found: {full_path}")
                 paper_contents.append(f"File not found: {p.md_path}")

        # 检查是否成功读取到任何内容
        if not paper_contents:
            return jsonify({"error": f"任务 {task_id} 下无可读取内容的论文，无法进行对比。"}), 400

        # 构建 AI 输入
        ai_system_prompt = "你是一位学术论文解析助手，熟悉论文的结构和内容。请基于用户提供的多篇论文内容和对比提示，生成一份简洁的对比报告。"
        ai_user_prompt_parts = [f"请根据以下对比提示，对多篇论文进行对比分析：{comparison_prompt}\n\n"]
        for i, content in enumerate(paper_contents):
            ai_user_prompt_parts.append(f"--- 论文 {i+1} 内容 ---\n{content}\n\n")

        ai_user_prompt = "".join(ai_user_prompt_parts)

        comparison_result = call_aliyun_api(ai_system_prompt, ai_user_prompt)

        # 检查 AI 是否返回了错误
        if comparison_result.startswith("Error:"):
             print(f"ERROR: AI call failed for comparison: {comparison_result}")
             comparison_result = f"AI 生成对比报告时出错: {comparison_result}" # 生成一个错误报告内容

        return jsonify({"comparison_report": comparison_result}), 200

    except Exception as e:
        app.logger.error(f"AI 对比分析失败: {str(e)}", exc_info=True)
        return jsonify({"error": f"AI 对比分析失败: {str(e)}"}), 500
    finally:
        db.close()


@app.route('/api/report/<int:report_id>/content', methods=['GET'])
def get_report_content(report_id):
    """
    根据报告 ID 获取报告内容
    """
    db = SessionLocal()
    try:
        report = get_report_by_id(db, report_id)
        if not report:
            return jsonify({"error": "报告不存在"}), 404

        # 报告内容是 bytes，解码成字符串
        content_str = report.content.decode('utf-8')
        return jsonify({"content": content_str}), 200

    except Exception as e:
        app.logger.error(f"获取报告 {report_id} 内容失败: {str(e)}", exc_info=True)
        return jsonify({"error": f"获取报告内容失败: {str(e)}"}), 500
    finally:
        db.close()


@app.route('/api/papers/update-md-path', methods=['PATCH'])
def update_paper_md_path():
    """
    根据 task_id 和 file_name 列表，更新对应的 Paper 记录的 md_path 字段。
    """
    data = request.get_json(force=True)
    task_id = data.get("task_id")
    file_md_path_mapping = data.get("file_md_path_mapping", {}) # 例如: {"file1.pdf": "path/to/file1/full.md", "file2.pdf": "path/to/file2/full.md"}

    if not task_id or not file_md_path_mapping:
        return jsonify({"error": "缺少必要参数 (task_id, file_md_path_mapping)"}), 400

    db = SessionLocal()
    try:
        updated_count = 0
        for file_name, md_path in file_md_path_mapping.items():
            # 查询 task_id 和 file_name 对应的 Paper 记录
            paper = db.query(Paper).filter(Paper.task_id == task_id, Paper.file_name == file_name).first()
            if paper:
                # --- 新增：打印更新前的值 ---
                print(f"DEBUG [update_paper_md_path]: Before update - Paper ID {paper.id}, File Name: {paper.file_name}, Current MD Path: {paper.md_path}")
                # --- 新增结束 ---
                paper.md_path = md_path # 更新 md_path
                # --- 新增：打印更新后的值 ---
                print(f"DEBUG [update_paper_md_path]: After update - Paper ID {paper.id}, File Name: {paper.file_name}, New MD Path: {paper.md_path}")
                # --- 新增结束 ---
                updated_count += 1
            else:
                print(f"WARNING [update_paper_md_path]: Paper with task_id {task_id} and file_name {file_name} not found.")

        # --- 新增：在 commit 前打印本次操作的摘要 ---
        print(f"DEBUG [update_paper_md_path]: About to commit changes. Task ID: {task_id}, Number of papers to update: {len(file_md_path_mapping)}, Number of papers actually updated: {updated_count}")
        # --- 新增结束 ---
        db.commit()
        return jsonify({"message": f"成功更新 {updated_count} 个论文的 md_path"}), 200

    except Exception as e:
        db.rollback()
        app.logger.error(f"更新论文 md_path 失败: {str(e)}", exc_info=True)
        return jsonify({"error": f"更新论文 md_path 失败: {str(e)}"}), 500
    finally:
        db.close()


@app.route('/api/users/all', methods=['GET'])
def get_all_users():
    """
    获取所有用户列表 (仅限管理员)
    """
    # --- 检查管理员权限 ---
    # 这里假设通过 session 获取当前登录用户 ID

    user_id_str = request.args.get('user_id') # 从 URL 查询参数中获取 user_id
    if user_id_str is None:
        return jsonify({"error": "缺少 user_id 参数"}), 400 # 返回 400 错误

    try:
        user_id = int(user_id_str) # 尝试转换为整数
    except ValueError:
        return jsonify({"error": "user_id 必须是整数"}), 400 # 返回 400 错误

    # 识别管理员：通过 username 或 user_id
    # 假设 admin 的 username 是 'admin' 或 user_id 是 1 (根据您的数据库情况调整)
    # 从数据库获取当前用户的用户名
    db_session = SessionLocal()
    try:
        current_user_obj = db_session.query(User).filter(User.id == user_id).first()
        if not current_user_obj:
             print(f"ERROR: User ID {user_id} not found in database during admin check.")
             return jsonify({"error": "用户信息错误"}), 401
        if current_user_obj.username != 'Admin': #  'Admin' 为您实际的管理员用户名
            # 或者使用 user_id: if current_user_id != 1: # 修改 1 为您实际的管理员 ID
            print(f"Unauthorized access attempt to /api/users/all by user_id {user_id} (username: {current_user_obj.username}).")
            return jsonify({"error": "权限不足，仅管理员可访问"}), 403
    finally:
        db_session.close()

    # --- 获取所有用户 ---
    db_users = SessionLocal()
    try:
        all_users = db_users.query(User).all()
        users_list = [{"id": u.id, "username": u.username, "email": u.email} for u in all_users]
        return jsonify(users_list), 200
    except Exception as e:
        app.logger.error(f"获取用户列表失败: {str(e)}", exc_info=True)
        return jsonify({"error": "获取用户列表失败"}), 500
    finally:
        db_users.close()


if __name__ == '__main__':
    # 仅用于开发！生产环境用Waitress
    app.run(host='0.0.0.0', port=5000, debug=True)