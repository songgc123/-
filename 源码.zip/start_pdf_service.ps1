# C:\Users\Administrator\Desktop\Project\start_pdf_service.ps1

# Conda 环境名称
$envName = "pdf_env" # <--- 确认你的环境名称

# 项目路径 (Flask 应用文件所在目录)
# 注意：Flask app.py 在 main 目录下
$projectPath = "C:\Users\Administrator\Desktop\Project\main" # <--- 指向 main 目录

# 切换到项目目录 (main 目录，因为 app.py 在这里)
Set-Location $projectPath

# --- 新增：设置 Hugging Face 镜像站环境变量 ---
$env:HF_ENDPOINT="https://hf-mirror.com"
Write-Host "✅ 环境变量 HF_ENDPOINT 已设置为: $env:HF_ENDPOINT" -ForegroundColor Green
# --- 新增结束 ---

# 启动 Flask 应用 (使用 Waitress)，在指定环境中运行
Write-Host "Starting AI Q&A Service..." -ForegroundColor Cyan
# 注意：app.py 在当前目录 (main) 下，所以 conda run 需要在这个目录下执行
& conda run --no-capture-output -n $envName waitress-serve --host=0.0.0.0 --port=5000 app:app